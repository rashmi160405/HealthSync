"""
Comprehensive Integration and Verification Test for HealthSync Backend.
Tests both Clinical ANN and ECG 1D-CNN modules, including Stage 2 Raw ECG Recording Analysis:
1. Clinical & ECG artifact loading (models, preprocessor, metadata, Grad-CAM sub-model).
2. GET / (API status, metadata, endpoints).
3. GET /health (Health check, clinical & ecg status breakdown, backward compatibility).
4. Clinical 20-feature shape & preprocessing.
5. POST /predict/clinical (Low Risk & High Risk).
6. POST /explain/clinical (Real SHAP and LIME computations).
7. Clinical input validation & boundary checks.
8. POST /predict/ecg with valid Normal and PVC heartbeats (shape 256, 2).
9. POST /explain/ecg with target_class=0, target_class=1, and target_class=None (256 finite Grad-CAM values).
10. ECG input validation (dimension mismatch, invalid channels, NaN values, Inf values).
11. STAGE 2: POST /ecg/analyze-sample-100 (WFDB decoding of 100.dat/100.hea/100.atr, Butterworth filtering, segmentation, inference, features).
12. STAGE 2: GET /ecg/recording/{recording_id} (Session caching & metadata verification).
13. STAGE 2: GET /ecg/recording/{recording_id}/beats/{beat_index} (Beat inspection & live 1D Grad-CAM on conv1d_2).
14. STAGE 2: GET /ecg/recording/{recording_id}/signal (Continuous signal slicing).
"""

import os
import sys
import numpy as np

# Line buffering
sys.stdout.reconfigure(line_buffering=True)
sys.stderr.reconfigure(line_buffering=True)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import main


def generate_synthetic_heartbeat(beat_type: str = "normal") -> list:
    """
    Generate a normalized synthetic 2-channel heartbeat of length 256.
    Follows Colab normalization:
      mean = beat.mean(axis=0)
      std = beat.std(axis=0)
      beat = (beat - mean) / (std + 1e-8)
    """
    t = np.linspace(0, 1, 256)
    if beat_type == "normal":
        ch1 = (
            0.15 * np.exp(-((t - 0.20) ** 2) / 0.002)
            - 0.20 * np.exp(-((t - 0.33) ** 2) / 0.0005)
            + 1.20 * np.exp(-((t - 0.36) ** 2) / 0.0008)
            - 0.30 * np.exp(-((t - 0.39) ** 2) / 0.0005)
            + 0.25 * np.exp(-((t - 0.55) ** 2) / 0.008)
        )
        ch2 = 0.8 * ch1 + 0.05 * np.sin(2 * np.pi * 5 * t)
    else:
        ch1 = (
            - 0.40 * np.exp(-((t - 0.25) ** 2) / 0.003)
            + 1.80 * np.exp(-((t - 0.32) ** 2) / 0.006)
            - 1.10 * np.exp(-((t - 0.42) ** 2) / 0.008)
            - 0.40 * np.exp(-((t - 0.60) ** 2) / 0.015)
        )
        ch2 = 0.9 * ch1 + 0.1 * np.cos(2 * np.pi * 3 * t)

    beat = np.column_stack([ch1, ch2]).astype(np.float32)
    mean = beat.mean(axis=0)
    std = beat.std(axis=0)
    beat = (beat - mean) / (std + 1e-8)
    return beat.tolist()


def run_tests():
    print("=" * 75)
    print("HEALTHSYNC INTEGRATED BACKEND VERIFICATION SUITE (STAGE 1 & STAGE 2)")
    print("=" * 75)

    # 1. Load artifacts
    print("\n[TEST 1] Loading models, preprocessor, and feature names...")
    main.load_artifacts()
    assert main.state["model"] is not None, "Clinical ANN model failed to load!"
    assert main.state["preprocessor"] is not None, "Clinical preprocessor failed to load!"
    assert len(main.state["feature_names"]) == 20, f"Expected 20 feature names, got {len(main.state['feature_names'])}"
    assert main.state["ecg_model"] is not None, "ECG 1D-CNN model failed to load!"
    assert main.state["ecg_grad_model"] is not None, "ECG Grad-CAM sub-model failed to build!"
    print("  -> PASSED: Clinical Keras Sequential ANN model loaded.")
    print("  -> PASSED: Colab clinical preprocessor loaded.")
    print("  -> PASSED: Exactly 20 clinical feature names loaded.")
    print("  -> PASSED: ECG Keras Sequential 1D-CNN model loaded.")
    print("  -> PASSED: ECG Functional 1D Grad-CAM sub-model compiled.")

    # 2. Test root endpoint
    print("\n[TEST 2] Testing GET / endpoint...")
    root_res = main.root()
    assert root_res["status"] == "online"
    assert "version" in root_res
    assert "endpoints" in root_res
    endpoints = root_res["endpoints"]
    assert "predict_clinical" in endpoints and "explain_clinical" in endpoints
    assert "predict_ecg" in endpoints and "explain_ecg" in endpoints
    assert "analyze_recording" in endpoints and "analyze_sample_100" in endpoints
    print(f"  -> PASSED: Root status='{root_res['status']}', project='{root_res['project']}'")
    print(f"  -> PASSED: Endpoints exposed: {list(endpoints.keys())}")

    # 3. Test health check endpoint
    print("\n[TEST 3] Testing GET /health endpoint...")
    health_res = main.health_check()
    assert health_res["status"] == "healthy"
    assert health_res["model_loaded"] is True
    assert health_res["preprocessor_loaded"] is True
    assert health_res["explainers_loaded"] is True
    assert health_res["preprocessed_feature_count"] == 20
    assert "ecg" in health_res
    assert health_res["ecg"]["status"] == "ready"
    assert health_res["ecg"]["gradcam_layer"] == "conv1d_2"
    assert "clinical" in health_res
    assert health_res["clinical"]["status"] == "ready"
    print(f"  -> PASSED: Health check overall status='{health_res['status']}'")
    print(f"  -> PASSED: Clinical subsystem status='{health_res['clinical']['status']}'")
    print(f"  -> PASSED: ECG subsystem status='{health_res['ecg']['status']}'")

    # 4. Test Clinical Feature Transformation & 20-Feature Shape
    print("\n[TEST 4] Testing 20-feature input shape & preprocessing pipeline...")
    sample_low = main.ClinicalInput(
        Age=54,
        Sex="M",
        ChestPainType="ATA",
        RestingBP=130,
        Cholesterol=220,
        FastingBS=0,
        RestingECG="Normal",
        MaxHR=150,
        ExerciseAngina="N",
        Oldpeak=1.5,
        ST_Slope="Up",
    )
    X_proc = main.prepare_features(sample_low)
    assert X_proc.shape == (1, 20), f"Expected shape (1, 20), got {X_proc.shape}"
    print(f"  -> PASSED: Output shape is exactly {X_proc.shape}.")

    # 5. Test Clinical Prediction (Low Risk)
    print("\n[TEST 5] Testing POST /predict/clinical (Low Risk)...")
    pred_low = main.predict_clinical(sample_low)
    assert pred_low["status"] == "success"
    assert pred_low["prediction"] == 0
    assert pred_low["risk"] == "Low"
    assert pred_low["feature_count_processed"] == 20
    print(f"  -> PASSED: Low Risk probability = {pred_low['probability_percent']}% (Risk: {pred_low['risk']})")

    # 6. Test Clinical Prediction (High Risk)
    print("\n[TEST 6] Testing POST /predict/clinical (High Risk)...")
    sample_high = main.ClinicalInput(
        Age=65,
        Sex="M",
        ChestPainType="ASY",
        RestingBP=160,
        Cholesterol=280,
        FastingBS=1,
        RestingECG="LVH",
        MaxHR=105,
        ExerciseAngina="Y",
        Oldpeak=3.2,
        ST_Slope="Flat",
    )
    pred_high = main.predict_clinical(sample_high)
    assert pred_high["status"] == "success"
    assert pred_high["prediction"] == 1
    assert pred_high["risk"] == "High"
    assert pred_high["probability_percent"] > 50.0
    print(f"  -> PASSED: High Risk probability = {pred_high['probability_percent']}% (Risk: {pred_high['risk']})")

    # 7. Test Clinical Explainability (SHAP & LIME)
    print("\n[TEST 7] Testing POST /explain/clinical (Real SHAP and LIME)...")
    exp_res = main.explain_clinical(sample_high)
    assert exp_res["status"] == "success"
    assert len(exp_res["shap"]) > 0, "No SHAP values returned!"
    assert len(exp_res["lime"]) > 0, "No LIME rules returned!"
    print(f"  -> PASSED: SHAP generated {len(exp_res['shap'])} feature attributions.")
    print(f"  -> PASSED: LIME generated {len(exp_res['lime'])} local explanation rules.")

    # 8. Test Clinical Input Validation
    print("\n[TEST 8] Testing clinical input validation & boundary checks...")
    try:
        main.ClinicalInput(
            Age=150,
            Sex="M",
            ChestPainType="ATA",
            RestingBP=130,
            Cholesterol=220,
            FastingBS=0,
            RestingECG="Normal",
            MaxHR=150,
            ExerciseAngina="N",
            Oldpeak=1.5,
            ST_Slope="Up",
        )
        assert False, "Validation failed to catch invalid Age=150!"
    except Exception:
        print("  -> PASSED: Invalid Age=150 rejected.")

    # 9. Test ECG Prediction (POST /predict/ecg)
    print("\n[TEST 9] Testing POST /predict/ecg (Normal & PVC Heartbeats)...")
    normal_beat = generate_synthetic_heartbeat("normal")
    pvc_beat = generate_synthetic_heartbeat("pvc")

    pred_ecg_norm = main.predict_ecg(main.ECGHeartbeatInput(signal=normal_beat))
    assert pred_ecg_norm["status"] == "success"
    assert pred_ecg_norm["predicted_class"] in [0, 1]
    assert pred_ecg_norm["input_shape"] == [256, 2]
    print(f"  -> PASSED: Normal Beat -> {pred_ecg_norm['class_label']} (Confidence: {pred_ecg_norm['confidence_percent']}%)")

    pred_ecg_pvc = main.predict_ecg(main.ECGHeartbeatInput(signal=pvc_beat))
    assert pred_ecg_pvc["status"] == "success"
    assert pred_ecg_pvc["predicted_class"] in [0, 1]
    print(f"  -> PASSED: PVC Beat -> {pred_ecg_pvc['class_label']} (Confidence: {pred_ecg_pvc['confidence_percent']}%)")

    # 10. Test ECG 1D Grad-CAM (POST /explain/ecg)
    print("\n[TEST 10] Testing POST /explain/ecg (1D Grad-CAM on conv1d_2)...")
    exp_ecg_pvc = main.explain_ecg(main.ECGExplanationInput(signal=pvc_beat, target_class=1))
    assert exp_ecg_pvc["status"] == "success"
    assert exp_ecg_pvc["target_class"] == 1
    assert exp_ecg_pvc["gradcam_layer"] == "conv1d_2"
    assert len(exp_ecg_pvc["gradcam_activations"]) == 256
    acts_pvc = np.array(exp_ecg_pvc["gradcam_activations"])
    assert np.all(np.isfinite(acts_pvc)) and np.all((acts_pvc >= 0.0) & (acts_pvc <= 1.0))
    print(f"  -> PASSED: Grad-CAM for PVC: 256 values in [{acts_pvc.min()}, {acts_pvc.max()}]")

    # 11. Test STAGE 2: Real Raw ECG Analysis (POST /ecg/analyze-sample-100)
    print("\n[TEST 11] STAGE 2: Testing POST /ecg/analyze-sample-100 (MIT-BIH Record 100)...")
    analysis = main.analyze_sample_100()
    assert "recording_id" in analysis
    rec_id = analysis["recording_id"]
    meta = analysis["metadata"]
    feats = analysis["features"]
    beats = analysis["beats"]

    # Verify metadata
    assert meta["sampling_frequency"] == 360, f"Expected 360 Hz, got {meta['sampling_frequency']}"
    assert meta["number_of_channels"] == 2, f"Expected 2 channels, got {meta['number_of_channels']}"
    assert meta["total_samples"] == 650000, f"Expected 650000 samples, got {meta['total_samples']}"
    print(f"  -> PASSED: Record '{analysis['record_name']}' decoded: fs={meta['sampling_frequency']}Hz, channels={meta['number_of_channels']}, duration={meta['duration_formatted']}")

    # Verify features
    assert feats["heart_rate_bpm"] > 50.0, f"Invalid HR: {feats['heart_rate_bpm']}"
    assert feats["number_of_detected_beats"] > 2000, f"Unexpected beat count: {feats['number_of_detected_beats']}"
    assert feats["normal_beat_count"] > 2000
    assert feats["pvc_beat_count"] >= 1, "Expected at least 1 PVC in record 100!"
    print(f"  -> PASSED: Real Features computed:")
    print(f"     • Heart Rate: {feats['heart_rate_bpm']} bpm (Mean RR: {feats['mean_rr_ms']} ms, SDNN: {feats['sdnn_ms']} ms)")
    print(f"     • QRS Duration: {feats['qrs_duration_ms']} ms ({feats['qrs_measurement_method']})")
    print(f"     • Total Beats: {feats['number_of_detected_beats']}, Normal: {feats['normal_beat_count']}, PVC: {feats['pvc_beat_count']} ({feats['pvc_percentage']}%)")

    # Verify continuous signal excerpt
    cont = analysis["continuous_signal"]
    assert len(cont["times"]) == 3600
    assert len(cont["lead_0"]) == 3600
    assert len(cont["lead_1"]) == 3600
    assert len(cont["r_peaks"]) > 0
    print(f"  -> PASSED: Continuous signal excerpt: {len(cont['times'])} points, {len(cont['r_peaks'])} R-peaks marked.")

    # 12. Test STAGE 2: GET /ecg/recording/{recording_id}
    print("\n[TEST 12] STAGE 2: Testing GET /ecg/recording/{recording_id}...")
    cached = main.get_recording(rec_id)
    assert cached["recording_id"] == rec_id
    assert len(cached["beats"]) == len(beats)
    print(f"  -> PASSED: Cached session retrieved successfully with {len(cached['beats'])} beats.")

    # 13. Test STAGE 2: GET /ecg/recording/{recording_id}/beats/{beat_index}
    print("\n[TEST 13] STAGE 2: Testing single beat inspection and live 1D Grad-CAM...")
    # Inspect first beat
    beat_0 = main.get_recording_beat(rec_id, 0)
    assert beat_0["status"] == "success"
    assert len(beat_0["raw_signal"]) == 256
    assert len(beat_0["normalized_signal"]) == 256
    assert len(beat_0["gradcam_activations"]) == 256
    acts_b0 = np.array(beat_0["gradcam_activations"])
    assert np.all(np.isfinite(acts_b0)) and np.all((acts_b0 >= 0.0) & (acts_b0 <= 1.0))
    print(f"  -> PASSED: Beat #0: label={beat_0['summary']['class_label']}, Grad-CAM length=256, max={acts_b0.max()}")

    # Find and inspect the PVC beat
    pvc_indices = [b["beat_index"] for b in beats if b["class_label"] == "PVC"]
    if pvc_indices:
        pvc_idx = pvc_indices[0]
        beat_pvc = main.get_recording_beat(rec_id, pvc_idx)
        assert beat_pvc["summary"]["class_label"] == "PVC"
        assert beat_pvc["summary"]["pvc_probability"] >= 0.5
        acts_bpvc = np.array(beat_pvc["gradcam_activations"])
        assert len(acts_bpvc) == 256 and np.all(np.isfinite(acts_bpvc))
        print(f"  -> PASSED: PVC Beat #{pvc_idx}: sample={beat_pvc['summary']['r_peak_sample']}, PVC Prob={beat_pvc['summary']['pvc_percent']}%, Grad-CAM max={acts_bpvc.max()}")

    # 14. Test STAGE 2: GET /ecg/recording/{recording_id}/signal
    print("\n[TEST 14] STAGE 2: Testing GET /ecg/recording/{recording_id}/signal...")
    sliced_sig = main.get_recording_signal(rec_id, start_sec=10.0, duration_sec=5.0)
    assert sliced_sig["status"] == "success"
    assert len(sliced_sig["times"]) == int(5.0 * 360)
    assert len(sliced_sig["lead_0"]) == int(5.0 * 360)
    print(f"  -> PASSED: Sliced signal [10s to 15s]: {len(sliced_sig['times'])} points, {len(sliced_sig['r_peaks'])} R-peaks.")

    print("\n" + "=" * 75)
    print("ALL 14 INTEGRATED VERIFICATION TESTS PASSED PERFECTLY!")
    print("=" * 75)


if __name__ == "__main__":
    run_tests()
