"""
HealthSync - Cardiovascular Screening & Explainable AI Backend
FastAPI service serving:
1. Clinical ANN model (Keras 3) & Colab scikit-learn preprocessing pipeline (SHAP & LIME).
2. ECG 1D-CNN Arrhythmia model (Keras 3) & 1D Grad-CAM explanation module (conv1d_2).
3. Raw ECG Analysis Pipeline (WFDB .dat + .hea + .atr, Butterworth bandpass, R-peak segmentation, batch prediction, Grad-CAM).
"""

import json
import logging
import os
import shutil
import tempfile
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple, Union

# Suppress TensorFlow logging & set writable matplotlib temp dir
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
os.environ["MPLCONFIGDIR"] = tempfile.gettempdir()

import joblib
import keras
import numpy as np
import pandas as pd
import scipy.signal
import tensorflow as tf
import wfdb
from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("healthsync")

# Paths to models
BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"

# Clinical Model Paths
CLINICAL_MODEL_PATH = MODELS_DIR / "healthsync_ann_model.keras"
MODEL_PATH = CLINICAL_MODEL_PATH  # Backward compatibility alias
PREPROCESSOR_PATH = MODELS_DIR / "healthsync_preprocessor.pkl"
FEATURE_NAMES_PATH = MODELS_DIR / "healthsync_feature_names.json"

# ECG Model Paths
ECG_DIR = MODELS_DIR / "ecg"
ECG_MODEL_PATH = ECG_DIR / "healthsync_ecg_cnn.keras"
ECG_METADATA_PATH = ECG_DIR / "ecg_metadata.json"
SAMPLE_DATA_DIR = BASE_DIR / "sample_data"

# Global application state
state: Dict[str, Any] = {
    # Clinical Model Artifacts
    "model": None,
    "preprocessor": None,
    "feature_names": [],
    "shap_explainer": None,
    "lime_explainer": None,
    "clinical_load_error": None,
    # ECG Model Artifacts
    "ecg_model": None,
    "ecg_grad_model": None,
    "ecg_metadata": {},
    "ecg_load_error": None,
    # Combined legacy status
    "load_error": None,
}

# Cache for analyzed recordings (UUID -> Recording Analysis)
recording_cache: Dict[str, Dict[str, Any]] = {}

EXPECTED_INPUT_COLUMNS = [
    "Age",
    "Sex",
    "ChestPainType",
    "RestingBP",
    "Cholesterol",
    "FastingBS",
    "RestingECG",
    "MaxHR",
    "ExerciseAngina",
    "Oldpeak",
    "ST_Slope",
]

# Standard MIT-BIH Arrhythmia Database beat annotation symbols
BEAT_SYMBOLS = {
    "N", "L", "R", "B", "A", "a", "J", "S", "V", "r", "F", "e", "j", "n", "E", "/", "f", "Q", "?"
}


def load_clinical_artifacts():
    """Load the Keras ANN model, preprocessor, feature names, and XAI explainers."""
    try:
        logger.info("Loading clinical preprocessor from %s", PREPROCESSOR_PATH)
        if not PREPROCESSOR_PATH.exists():
            raise FileNotFoundError(f"Preprocessor file not found at {PREPROCESSOR_PATH}")
        state["preprocessor"] = joblib.load(PREPROCESSOR_PATH)

        logger.info("Loading clinical feature names from %s", FEATURE_NAMES_PATH)
        if not FEATURE_NAMES_PATH.exists():
            raise FileNotFoundError(f"Feature names file not found at {FEATURE_NAMES_PATH}")
        with open(FEATURE_NAMES_PATH, "r", encoding="utf-8") as f:
            state["feature_names"] = json.load(f)

        logger.info("Loading clinical Keras ANN model from %s", CLINICAL_MODEL_PATH)
        if not CLINICAL_MODEL_PATH.exists():
            raise FileNotFoundError(f"Keras model file not found at {CLINICAL_MODEL_PATH}")
        state["model"] = keras.models.load_model(CLINICAL_MODEL_PATH)

        # Initialize Explainers (SHAP & LIME)
        logger.info("Initializing clinical SHAP and LIME explainers...")
        background = np.zeros((1, 20))

        def predict_fn(x):
            return state["model"].predict(x, verbose=0)

        import shap
        from lime.lime_tabular import LimeTabularExplainer

        state["shap_explainer"] = shap.KernelExplainer(predict_fn, background)

        np.random.seed(42)
        lime_bg = np.random.normal(0, 1, size=(50, 20))
        state["lime_explainer"] = LimeTabularExplainer(
            training_data=lime_bg,
            feature_names=state["feature_names"],
            class_names=["Low Risk", "High Risk"],
            mode="classification",
            random_state=42,
        )

        state["clinical_load_error"] = None
        logger.info("Clinical artifacts and explainers loaded successfully.")
    except Exception as exc:
        logger.error("Failed to load clinical artifacts: %s", exc, exc_info=True)
        state["clinical_load_error"] = str(exc)


def load_ecg_artifacts():
    """Load the Keras 1D-CNN ECG model, metadata, and construct functional Grad-CAM sub-model."""
    try:
        logger.info("Loading ECG metadata from %s", ECG_METADATA_PATH)
        if not ECG_METADATA_PATH.exists():
            raise FileNotFoundError(f"ECG metadata file not found at {ECG_METADATA_PATH}")
        with open(ECG_METADATA_PATH, "r", encoding="utf-8") as f:
            state["ecg_metadata"] = json.load(f)

        logger.info("Loading ECG Keras 1D-CNN model from %s", ECG_MODEL_PATH)
        if not ECG_MODEL_PATH.exists():
            raise FileNotFoundError(f"ECG model file not found at {ECG_MODEL_PATH}")
        state["ecg_model"] = keras.models.load_model(ECG_MODEL_PATH)

        # Construct Functional Grad-CAM model to avoid Keras 3 Sequential layer output access error
        logger.info("Constructing functional 1D Grad-CAM model...")
        conv_layer_name = state["ecg_metadata"].get("gradcam_layer", "conv1d_2")
        input_shape = tuple(state["ecg_metadata"].get("input_shape", [256, 2]))

        inputs = keras.Input(shape=input_shape, name="ecg_input")
        x = inputs
        conv_output = None
        for layer in state["ecg_model"].layers:
            x = layer(x)
            if layer.name == conv_layer_name:
                conv_output = x

        if conv_output is None:
            raise ValueError(f"Target Grad-CAM convolution layer '{conv_layer_name}' not found in ECG model.")

        state["ecg_grad_model"] = keras.Model(inputs=inputs, outputs=[conv_output, x])
        state["ecg_load_error"] = None
        logger.info("ECG model and 1D Grad-CAM sub-model loaded successfully.")
    except Exception as exc:
        logger.error("Failed to load ECG artifacts: %s", exc, exc_info=True)
        state["ecg_load_error"] = str(exc)
        state["ecg_model"] = None
        state["ecg_grad_model"] = None


def load_artifacts():
    """Load all backend models independently. An error in one does not block the other."""
    load_clinical_artifacts()
    load_ecg_artifacts()
    state["load_error"] = state["clinical_load_error"] or state["ecg_load_error"]


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup and shutdown."""
    load_artifacts()
    yield


app = FastAPI(
    title="HealthSync – Explainable AI-Based Cardiovascular Screening & ECG Arrhythmia Platform",
    description=(
        "Backend API serving:\n"
        "1. Clinical ANN trained on the Heart Failure Prediction Dataset with SHAP & LIME.\n"
        "2. 1D CNN trained on ECG Arrhythmia heartbeat classifications (PVC vs Normal) with 1D Grad-CAM.\n"
        "3. Raw MIT-BIH ECG Recording Analysis (.dat, .hea, .atr) with Butterworth filtering, R-peak segmentation, and live Grad-CAM."
    ),
    version="1.2.0",
    lifespan=lifespan,
)

# CORS Middleware: allow requests from frontend dev servers and direct browser origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled server exception on %s: %s", request.url.path, exc, exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal server error: {str(exc)}"},
        headers={
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "*",
            "Access-Control-Allow-Headers": "*",
        },
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
        headers={
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "*",
            "Access-Control-Allow-Headers": "*",
        },
    )


# =====================================================================
# CLINICAL SCHEMAS & PREPROCESSING
# =====================================================================

class ClinicalInput(BaseModel):
    Age: int = Field(..., ge=1, le=120, description="Age in years (1 - 120)")
    Sex: Literal["M", "F", "m", "f"] = Field(..., description="Patient sex (M or F)")
    ChestPainType: Literal["TA", "ATA", "NAP", "ASY", "ta", "ata", "nap", "asy"] = Field(
        ..., description="Chest pain type: TA (Typical Angina), ATA (Atypical Angina), NAP (Non-Anginal Pain), ASY (Asymptomatic)"
    )
    RestingBP: float = Field(..., ge=60, le=250, description="Resting blood pressure in mmHg (60 - 250)")
    Cholesterol: float = Field(..., ge=0, le=600, description="Serum cholesterol in mg/dL (0 - 600)")
    FastingBS: int = Field(..., ge=0, le=1, description="Fasting blood sugar > 120 mg/dL: 1 for True, 0 for False")
    RestingECG: Literal["Normal", "ST", "LVH", "normal", "st", "lvh"] = Field(
        ..., description="Resting ECG results: Normal, ST (ST-T abnormality), LVH (left ventricular hypertrophy)"
    )
    MaxHR: float = Field(..., ge=50, le=250, description="Maximum heart rate achieved in bpm (50 - 250)")
    ExerciseAngina: Literal["Y", "N", "y", "n"] = Field(..., description="Exercise-induced angina: Y or N")
    Oldpeak: float = Field(..., ge=-5.0, le=10.0, description="ST depression induced by exercise relative to rest (-5.0 to 10.0)")
    ST_Slope: Literal["Up", "Flat", "Down", "up", "flat", "down"] = Field(
        ..., description="Slope of the peak exercise ST segment: Up, Flat, Down"
    )

    @field_validator("Sex", mode="before")
    @classmethod
    def normalize_sex(cls, v):
        if isinstance(v, str):
            return v.strip().upper()
        return v

    @field_validator("ChestPainType", mode="before")
    @classmethod
    def normalize_chest_pain(cls, v):
        if isinstance(v, str):
            return v.strip().upper()
        return v

    @field_validator("RestingECG", mode="before")
    @classmethod
    def normalize_resting_ecg(cls, v):
        if isinstance(v, str):
            v_clean = v.strip().upper()
            if v_clean == "NORMAL":
                return "Normal"
            return v_clean
        return v

    @field_validator("ExerciseAngina", mode="before")
    @classmethod
    def normalize_exercise_angina(cls, v):
        if isinstance(v, str):
            return v.strip().upper()
        return v

    @field_validator("ST_Slope", mode="before")
    @classmethod
    def normalize_st_slope(cls, v):
        if isinstance(v, str):
            v_clean = v.strip().capitalize()
            if v_clean in ["Up", "Flat", "Down"]:
                return v_clean
        return v

    model_config = {
        "json_schema_extra": {
            "example": {
                "Age": 54,
                "Sex": "M",
                "ChestPainType": "ATA",
                "RestingBP": 130,
                "Cholesterol": 220,
                "FastingBS": 0,
                "RestingECG": "Normal",
                "MaxHR": 150,
                "ExerciseAngina": "N",
                "Oldpeak": 1.5,
                "ST_Slope": "Up",
            }
        }
    }


def prepare_features(input_data: ClinicalInput) -> np.ndarray:
    """
    Format inputs into a pandas DataFrame matching the Kaggle dataset structure,
    then transform through the loaded Colab preprocessor.
    Ensures exactly 20 features in the exact trained ordering.
    """
    if state["preprocessor"] is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Clinical preprocessing pipeline is not loaded. Error: {state['clinical_load_error']}",
        )

    row = {
        "Age": [input_data.Age],
        "Sex": [input_data.Sex],
        "ChestPainType": [input_data.ChestPainType],
        "RestingBP": [input_data.RestingBP],
        "Cholesterol": [input_data.Cholesterol],
        "FastingBS": [input_data.FastingBS],
        "RestingECG": [input_data.RestingECG],
        "MaxHR": [input_data.MaxHR],
        "ExerciseAngina": [input_data.ExerciseAngina],
        "Oldpeak": [input_data.Oldpeak],
        "ST_Slope": [input_data.ST_Slope],
    }
    df = pd.DataFrame(row, columns=EXPECTED_INPUT_COLUMNS)

    try:
        X_proc = state["preprocessor"].transform(df)
    except Exception as exc:
        logger.error("Error transforming clinical input dataframe: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Preprocessing transformation failed: {str(exc)}",
        )

    if X_proc.shape[1] != 20:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Feature shape mismatch: expected 20 preprocessed features, got {X_proc.shape[1]}",
        )

    return X_proc


# =====================================================================
# ECG SCHEMAS & 1D GRAD-CAM
# =====================================================================

class ECGHeartbeatInput(BaseModel):
    signal: List[List[float]] = Field(
        ...,
        description="Segmented and normalized 2-channel heartbeat of shape (256, 2). 256 time samples x 2 channels.",
    )

    @field_validator("signal")
    @classmethod
    def validate_signal(cls, v):
        if not isinstance(v, list) or len(v) == 0:
            raise ValueError("ECG signal must be a non-empty 2D list.")

        try:
            arr = np.array(v, dtype=np.float32)
        except Exception as exc:
            raise ValueError(f"Could not convert ECG signal to numeric array: {exc}")

        if arr.ndim != 2:
            raise ValueError(f"ECG signal must be a 2D array of shape (256, 2), received {arr.ndim}D array with shape {arr.shape}.")

        # Handle transpose if caller supplied (2, 256)
        if arr.shape == (2, 256):
            arr = arr.T

        if arr.shape != (256, 2):
            raise ValueError(f"Invalid ECG heartbeat dimensions: expected exactly shape (256, 2) [256 samples, 2 channels], received shape {arr.shape}.")

        # Reject NaN, Inf, -Inf
        if not np.all(np.isfinite(arr)):
            raise ValueError("ECG signal contains invalid numeric values (NaN or Infinite values).")

        return arr.tolist()

    model_config = {
        "json_schema_extra": {
            "example": {
                "signal": [[0.0, 0.0] for _ in range(256)]
            }
        }
    }


class ECGExplanationInput(BaseModel):
    signal: List[List[float]] = Field(
        ...,
        description="Segmented and normalized 2-channel heartbeat of shape (256, 2). 256 time samples x 2 channels.",
    )
    target_class: Optional[Union[int, str]] = Field(
        default=None,
        description="Target class for 1D Grad-CAM explanation: 0/'Normal' or 1/'PVC'. If omitted, defaults to the predicted class.",
    )

    @field_validator("signal")
    @classmethod
    def validate_signal(cls, v):
        return ECGHeartbeatInput.validate_signal(v)

    @field_validator("target_class", mode="before")
    @classmethod
    def normalize_target_class(cls, v):
        if v is None:
            return None
        if isinstance(v, str):
            v_clean = v.strip().lower()
            if v_clean in ["normal", "0"]:
                return 0
            elif v_clean in ["pvc", "1"]:
                return 1
            else:
                raise ValueError(f"Invalid target_class '{v}'. Allowed values are 0/'Normal' or 1/'PVC'.")
        if isinstance(v, (int, float)):
            int_v = int(v)
            if int_v not in [0, 1]:
                raise ValueError(f"Invalid target_class {v}. Must be 0 (Normal) or 1 (PVC).")
            return int_v
        return v


def compute_1d_gradcam(signal_arr: np.ndarray, target_class: int) -> List[float]:
    """
    Computes 1D Grad-CAM for a heartbeat of shape (256, 2) against target_class (0=Normal, 1=PVC)
    using the feature maps from conv1d_2.
    Returns 256 normalized activation values in [0.0, 1.0].
    """
    if state["ecg_grad_model"] is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"ECG Grad-CAM gradient model is not available. Error: {state['ecg_load_error']}",
        )

    x_tensor = tf.convert_to_tensor(np.expand_dims(signal_arr, axis=0), dtype=tf.float32)

    with tf.GradientTape() as tape:
        conv_outputs, predictions = state["ecg_grad_model"](x_tensor, training=False)
        tape.watch(conv_outputs)
        pvc_prob = predictions[:, 0]
        # Class 1 = PVC, Class 0 = Normal (1 - PVC)
        score = pvc_prob if target_class == 1 else (1.0 - pvc_prob)

    grads = tape.gradient(score, conv_outputs)
    if grads is None:
        logger.warning("Grad-CAM tape returned None gradients.")
        return [0.0] * 256

    # Global average pooling over the time dimension (axis 1): shape (1, 128)
    weights = tf.reduce_mean(grads, axis=1)

    # Channel-weighted linear combination: (1, 64, 128) * (1, 1, 128) summed over channels -> (1, 64)
    cam = tf.reduce_sum(conv_outputs * tf.expand_dims(weights, axis=1), axis=-1)

    # ReLU to keep only features that have a positive influence on the target class
    cam = tf.nn.relu(cam)

    # Resize/interpolate from 64 to 256 samples
    cam_expanded = tf.expand_dims(tf.expand_dims(cam, -1), -1)  # (1, 64, 1, 1)
    cam_resized = tf.image.resize(cam_expanded, [256, 1], method="bilinear")
    cam_1d = tf.squeeze(cam_resized).numpy()

    # Normalize between 0.0 and 1.0
    max_val = float(np.max(cam_1d))
    if max_val > 0.0:
        cam_norm = cam_1d / max_val
    else:
        cam_norm = cam_1d

    cam_clean = np.nan_to_num(cam_norm, nan=0.0, posinf=1.0, neginf=0.0).tolist()
    return [round(float(v), 5) for v in cam_clean]


# =====================================================================
# REAL RAW ECG PROCESSING PIPELINE (WFDB + BUTTERWORTH + SEGMENTATION)
# =====================================================================

def sanitize_for_json(obj: Any) -> Any:
    """
    Recursively converts NumPy scalars and arrays into native Python types (int, float, list, bool)
    to prevent FastAPI / Starlette jsonable_encoder TypeError: 'numpy.int64' object is not iterable.
    """
    if isinstance(obj, dict):
        return {k: sanitize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [sanitize_for_json(v) for v in obj]
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return sanitize_for_json(obj.tolist())
    elif isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    return obj


def detect_r_peaks_algorithmic(signal: np.ndarray, fs: int) -> List[int]:
    """
    Pan-Tompkins energy derivative R-peak detection method for recordings without annotations.
    Applied to Lead 0 (typically MLII / modified Lead II).
    Returns pure Python int sample indices.
    """
    diff = np.diff(signal)
    squared = diff ** 2
    kernel_size = max(5, int(0.12 * fs))
    integrated = np.convolve(squared, np.ones(kernel_size) / kernel_size, mode="same")

    min_dist = max(10, int(0.25 * fs))  # physiological refractory period (~250 ms)
    thresh = float(np.mean(integrated) * 1.5)
    if thresh <= 0:
        thresh = float(np.max(integrated) * 0.3) if np.max(integrated) > 0 else 0.1

    peaks, _ = scipy.signal.find_peaks(integrated, distance=min_dist, height=thresh)

    # Align each detected energy peak with the actual signal peak in Lead 0
    search_radius = max(3, int(0.08 * fs))
    r_peaks: List[int] = []
    for p in peaks:
        p_int = int(p)
        start_idx = max(0, p_int - search_radius)
        end_idx = min(len(signal), p_int + search_radius)
        if end_idx > start_idx:
            local_max = start_idx + int(np.argmax(signal[start_idx:end_idx]))
            r_peaks.append(int(local_max))

    return sorted(list(set(int(x) for x in r_peaks)))


def estimate_qrs_duration(signal: np.ndarray, r_peaks: List[int], fs: int) -> Tuple[Optional[float], str]:
    """
    Estimates QRS duration (ms) from Lead 0 by detecting Q and S inflection boundaries.
    Returns (median_qrs_ms, method_note).
    """
    durations = []
    for r in r_peaks[:500]:  # sample up to first 500 beats for speed and accuracy
        if r >= 25 and (r + 30) < len(signal):
            # Q wave is local trough in [r - 20 : r]
            q_win = signal[r - 20 : r]
            q_pos = r - 20 + int(np.argmin(q_win))

            # S wave is local trough in [r : r + 25]
            s_win = signal[r : r + 25]
            s_pos = r + int(np.argmin(s_win))

            # Onset inflection before Q
            pre_q = signal[max(0, q_pos - 15) : q_pos]
            if len(pre_q) > 1:
                diff_pre = np.abs(np.diff(pre_q))
                onset = max(0, q_pos - 15) + int(np.argmin(diff_pre))
            else:
                onset = q_pos - 5

            # Offset J-point leveling after S
            post_s = signal[s_pos : min(len(signal), s_pos + 18)]
            if len(post_s) > 1:
                diff_post = np.abs(np.diff(post_s))
                offset = s_pos + int(np.argmin(diff_post))
            else:
                offset = s_pos + 5

            dur = (offset - onset) / fs * 1000.0
            if 50.0 <= dur <= 160.0:
                durations.append(dur)

    if durations:
        return round(float(np.median(durations)), 1), "Q-to-S inflection derivative thresholding on Lead I"
    return None, "Not reliably measurable on current lead morphology"


def process_ecg_dataset(record_dir: Path, record_name: str, has_atr: bool = False) -> Dict[str, Any]:
    """
    Core pipeline to read, preprocess, segment, classify, and explain a raw MIT-BIH ECG record.
    Follows Colab model training specifications exactly.
    """
    if state["ecg_model"] is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"ECG 1D-CNN model is not loaded. Error: {state['ecg_load_error']}",
        )

    record_path_str = str(record_dir / record_name)

    # 1. Read WFDB record
    try:
        rec = wfdb.rdrecord(record_path_str)
    except Exception as exc:
        logger.error("WFDB rdrecord failed on %s: %s", record_path_str, exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Could not read WFDB recording files '{record_name}': {str(exc)}",
        )

    fs = int(rec.fs)
    n_sig = int(rec.n_sig)
    total_samples = int(rec.sig_len)
    duration_sec = round(float(total_samples / fs), 2)
    lead_names = list(rec.sig_name) if rec.sig_name else [f"Lead {i+1}" for i in range(n_sig)]

    if n_sig < 2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Recording '{record_name}' has {n_sig} channel(s). HealthSync ECG 1D-CNN requires at least 2 channels.",
        )

    # Extract first 2 channels
    raw_signal = rec.p_signal[:, :2].astype(np.float32)

    # 2. Fourth-order Butterworth bandpass filter (0.5 – 40 Hz)
    nyq = 0.5 * fs
    low = 0.5 / nyq
    high = min(40.0 / nyq, 0.99)
    b, a = scipy.signal.butter(4, [low, high], btype="band")
    filtered_signal = scipy.signal.filtfilt(b, a, raw_signal, axis=0).astype(np.float32)

    # 3. Read or detect R-peaks
    ann_symbols_map: Dict[int, str] = {}
    r_peaks: List[int] = []
    annotation_source = "Energy Derivative Peak Detector"

    if has_atr:
        try:
            ann = wfdb.rdann(record_path_str, "atr")
            for s, sym in zip(ann.sample, ann.symbol):
                if sym in BEAT_SYMBOLS:
                    ann_symbols_map[int(s)] = sym
            if ann_symbols_map:
                r_peaks = sorted(list(ann_symbols_map.keys()))
                annotation_source = f"WFDB Annotations (.atr: {len(r_peaks)} beats)"
        except Exception as exc:
            logger.warning("Could not read .atr file on %s: %s", record_name, exc)

    if not r_peaks:
        r_peaks = detect_r_peaks_algorithmic(filtered_signal[:, 0], fs)
        annotation_source = f"Algorithmic R-peak Detector ({len(r_peaks)} beats detected)"

    # 4. Beat Segmentation: 90 samples before R-peak and 166 samples after (total 256 samples)
    valid_r_peaks: List[int] = []
    raw_beats_list: List[np.ndarray] = []
    norm_beats_list: List[np.ndarray] = []

    for r in r_peaks:
        if r >= 90 and (r + 166) <= total_samples:
            seg_raw = filtered_signal[r - 90 : r + 166, :]  # shape (256, 2)
            m = seg_raw.mean(axis=0)
            s = seg_raw.std(axis=0)
            seg_norm = (seg_raw - m) / (s + 1e-8)

            valid_r_peaks.append(r)
            raw_beats_list.append(seg_raw)
            norm_beats_list.append(seg_norm)

    total_beats = len(valid_r_peaks)
    if total_beats == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"No valid heartbeat segments could be extracted from recording '{record_name}' within valid boundary ranges.",
        )

    # 5. Batch Model Prediction on Extracted Beats
    norm_tensor = np.array(norm_beats_list, dtype=np.float32)
    batch_preds = state["ecg_model"].predict(norm_tensor, batch_size=256, verbose=0)

    beat_summaries: List[Dict[str, Any]] = []
    first_pvc_idx: Optional[int] = None

    for i, r in enumerate(valid_r_peaks):
        r_val = int(r)
        pvc_prob = float(batch_preds[i][0])
        normal_prob = float(1.0 - pvc_prob)
        pred_class = 1 if pvc_prob >= 0.5 else 0
        class_label = "PVC" if pred_class == 1 else "Normal"
        conf = pvc_prob if pred_class == 1 else normal_prob

        if pred_class == 1 and first_pvc_idx is None:
            first_pvc_idx = i

        beat_summaries.append({
            "beat_index": int(i),
            "r_peak_sample": r_val,
            "time_sec": round(float(r_val / fs), 3),
            "predicted_class": int(pred_class),
            "class_label": class_label,
            "pvc_probability": round(pvc_prob, 4),
            "normal_probability": round(normal_prob, 4),
            "pvc_percent": round(pvc_prob * 100, 2),
            "normal_percent": round(normal_prob * 100, 2),
            "confidence": round(conf, 4),
            "confidence_percent": round(conf * 100, 2),
            "wfdb_annotation": str(ann_symbols_map.get(r_val)) if r_val in ann_symbols_map else None,
        })

    normal_count = sum(1 for b in beat_summaries if b["predicted_class"] == 0)
    pvc_count = sum(1 for b in beat_summaries if b["predicted_class"] == 1)
    pvc_percentage = round((pvc_count / total_beats) * 100, 2)

    # 6. Real Feature Calculation
    if total_beats >= 2:
        rr_diffs_ms = (np.diff(valid_r_peaks) / fs) * 1000.0
        mean_rr_ms = round(float(np.mean(rr_diffs_ms)), 1)
        min_rr_ms = round(float(np.min(rr_diffs_ms)), 1)
        max_rr_ms = round(float(np.max(rr_diffs_ms)), 1)
        sdnn_ms = round(float(np.std(rr_diffs_ms)), 1)
        heart_rate_bpm = round(float(60000.0 / mean_rr_ms), 1) if mean_rr_ms > 0 else 0.0
    else:
        mean_rr_ms = min_rr_ms = max_rr_ms = sdnn_ms = heart_rate_bpm = 0.0

    qrs_dur_ms, qrs_note = estimate_qrs_duration(filtered_signal[:, 0], valid_r_peaks, fs)

    # 7. Pre-compute Grad-CAM for Beat 0 and First PVC Beat
    beat_0_gradcam = compute_1d_gradcam(norm_beats_list[0], target_class=beat_summaries[0]["predicted_class"])
    first_pvc_gradcam = None
    if first_pvc_idx is not None:
        first_pvc_gradcam = {
            "beat_index": first_pvc_idx,
            "activations": compute_1d_gradcam(norm_beats_list[first_pvc_idx], target_class=1),
            "summary": beat_summaries[first_pvc_idx],
        }

    # 8. Continuous Signal Excerpt for Waveform Canvas (first 10 seconds or up to 3600 samples)
    excerpt_samples = min(3600, total_samples)
    excerpt_times = [round(float(idx / fs), 4) for idx in range(excerpt_samples)]
    excerpt_lead0 = [round(float(v), 4) for v in filtered_signal[:excerpt_samples, 0]]
    excerpt_lead1 = [round(float(v), 4) for v in filtered_signal[:excerpt_samples, 1]]

    # R-peaks within excerpt
    excerpt_peaks = [
        b for b in beat_summaries if b["r_peak_sample"] < excerpt_samples
    ]

    # Decimated overview of full recording (800 points max for overview ribbon)
    decimate_step = max(1, total_samples // 800)
    overview_times = [round(float(i / fs), 2) for i in range(0, total_samples, decimate_step)]
    overview_lead0 = [round(float(filtered_signal[i, 0]), 4) for i in range(0, total_samples, decimate_step)]

    recording_id = str(uuid.uuid4())

    analysis_data = {
        "recording_id": recording_id,
        "record_name": record_name,
        "metadata": {
            "sampling_frequency": fs,
            "number_of_channels": n_sig,
            "lead_names": lead_names[:2],
            "total_samples": total_samples,
            "duration_seconds": duration_sec,
            "duration_formatted": f"{int(duration_sec // 60)}m {int(duration_sec % 60)}s",
            "annotation_source": annotation_source,
            "has_annotations": bool(ann_symbols_map),
        },
        "features": {
            "heart_rate_bpm": heart_rate_bpm,
            "mean_rr_ms": mean_rr_ms,
            "min_rr_ms": min_rr_ms,
            "max_rr_ms": max_rr_ms,
            "sdnn_ms": sdnn_ms,
            "qrs_duration_ms": qrs_dur_ms,
            "qrs_measurement_method": qrs_note,
            "number_of_detected_beats": total_beats,
            "normal_beat_count": normal_count,
            "pvc_beat_count": pvc_count,
            "pvc_percentage": pvc_percentage,
            "overall_classification": "Frequent PVC Arrhythmia Detected" if pvc_count > 5 else (
                "Occasional PVC Detected" if pvc_count > 0 else "Normal Sinus Rhythm"
            ),
        },
        "continuous_signal": {
            "excerpt_duration_seconds": round(float(excerpt_samples / fs), 2),
            "sampling_frequency": fs,
            "lead_names": lead_names[:2],
            "times": excerpt_times,
            "lead_0": excerpt_lead0,
            "lead_1": excerpt_lead1,
            "r_peaks": excerpt_peaks,
            "overview_times": overview_times,
            "overview_lead_0": overview_lead0,
        },
        "beats": beat_summaries,
        "selected_beat_gradcam": {
            "beat_index": 0,
            "summary": beat_summaries[0],
            "raw_signal": [list(np.round(seg, 4)) for seg in raw_beats_list[0].tolist()],
            "normalized_signal": [list(np.round(seg, 4)) for seg in norm_beats_list[0].tolist()],
            "gradcam_activations": beat_0_gradcam,
        },
        "first_pvc_gradcam": first_pvc_gradcam,
        "academic_disclaimer": "HealthSync is an academic research prototype. Not certified for clinical diagnosis.",
    }

    # Sanitize entire analysis_data to ensure 100% native Python types
    clean_analysis_data = sanitize_for_json(analysis_data)

    # Cache for beat-level inspection
    recording_cache[recording_id] = {
        "analysis_data": clean_analysis_data,
        "raw_beats": raw_beats_list,
        "norm_beats": norm_beats_list,
        "filtered_signal": filtered_signal,
        "fs": fs,
        "lead_names": lead_names[:2],
    }

    return clean_analysis_data


# =====================================================================
# API ENDPOINTS
# =====================================================================

@app.get("/", summary="API Root Status")
def root():
    """Return API metadata, status, and all available endpoints."""
    return {
        "project": "HealthSync – Explainable AI-Based Cardiovascular Screening & ECG Arrhythmia Platform",
        "status": "online",
        "version": "1.2.0",
        "academic_disclaimer": (
            "HealthSync is an academic research prototype. Predictions and explanations "
            "are demonstration outputs and are NOT certified for clinical diagnosis or treatment."
        ),
        "endpoints": {
            "health": "/health",
            "predict_clinical": "/predict/clinical",
            "explain_clinical": "/explain/clinical",
            "predict_ecg": "/predict/ecg",
            "explain_ecg": "/explain/ecg",
            "analyze_recording": "/ecg/analyze-recording",
            "analyze_sample_100": "/ecg/analyze-sample-100",
            "get_recording": "/ecg/recording/{recording_id}",
            "get_recording_beat": "/ecg/recording/{recording_id}/beats/{beat_index}",
            "get_recording_signal": "/ecg/recording/{recording_id}/signal",
            "docs": "/docs",
        },
    }


@app.get("/health", summary="Health and Model Loading Status")
def health_check():
    """Check backend status and loaded model artifacts for both Clinical ANN and ECG 1D-CNN."""
    clinical_ready = state["model"] is not None and state["preprocessor"] is not None
    ecg_ready = state["ecg_model"] is not None and state["ecg_grad_model"] is not None

    if clinical_ready and ecg_ready:
        overall_status = "healthy"
    elif clinical_ready or ecg_ready:
        overall_status = "degraded"
    else:
        overall_status = "unhealthy"

    return {
        "status": overall_status,
        # Top-level backwards compatibility fields for existing UI
        "model_loaded": state["model"] is not None,
        "preprocessor_loaded": state["preprocessor"] is not None,
        "explainers_loaded": state["shap_explainer"] is not None and state["lime_explainer"] is not None,
        "expected_input_features": len(EXPECTED_INPUT_COLUMNS),
        "preprocessed_feature_count": len(state["feature_names"]),
        "preprocessed_feature_names": state["feature_names"],
        "model_architecture": "Keras Sequential ANN [Dense(64) -> Dropout(0.3) -> Dense(32) -> Dropout(0.2) -> Dense(1)]",
        # Subsystem status: Clinical
        "clinical": {
            "status": "ready" if clinical_ready else "error",
            "model_loaded": state["model"] is not None,
            "preprocessor_loaded": state["preprocessor"] is not None,
            "explainers_loaded": state["shap_explainer"] is not None and state["lime_explainer"] is not None,
            "feature_count": len(state["feature_names"]),
            "error": state["clinical_load_error"],
        },
        # Subsystem status: ECG
        "ecg": {
            "status": "ready" if ecg_ready else "error",
            "model_loaded": state["ecg_model"] is not None,
            "gradcam_ready": state["ecg_grad_model"] is not None,
            "architecture": state["ecg_metadata"].get("model_type", "Sequential 1D CNN"),
            "gradcam_layer": state["ecg_metadata"].get("gradcam_layer", "conv1d_2"),
            "input_shape": state["ecg_metadata"].get("input_shape", [256, 2]),
            "classes": state["ecg_metadata"].get("classes", {"0": "Normal", "1": "PVC"}),
            "sampling_frequency": state["ecg_metadata"].get("sampling_frequency", 360),
            "cached_recordings": len(recording_cache),
            "error": state["ecg_load_error"],
        },
        "frameworks": {
            "keras": getattr(keras, "__version__", "unknown"),
            "tensorflow": getattr(tf, "__version__", "unknown"),
            "scikit_learn": getattr(joblib, "__version__", "unknown"),
            "scipy": getattr(scipy, "__version__", "unknown"),
            "wfdb": getattr(wfdb, "__version__", "unknown"),
        },
        "load_error": state["clinical_load_error"] or state["ecg_load_error"],
    }


# ---------------------------------------------------------------------
# CLINICAL PREDICTION & EXPLANATION
# ---------------------------------------------------------------------

@app.post("/predict/clinical", summary="Predict Heart Disease Risk from Clinical Features")
def predict_clinical(input_data: ClinicalInput):
    """
    Accepts 11 clinical features, applies the exact Colab preprocessor,
    and returns real predictions from the trained Keras ANN model.
    """
    if state["model"] is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Clinical ANN model is not loaded. Error: {state['clinical_load_error']}",
        )

    X_proc = prepare_features(input_data)

    try:
        raw_pred = state["model"].predict(X_proc, verbose=0)
        prob = float(raw_pred[0][0])
    except Exception as exc:
        logger.error("Clinical inference execution failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Clinical model inference failed: {str(exc)}",
        )

    prob_percent = round(prob * 100, 2)
    prediction = 1 if prob >= 0.5 else 0
    risk = "High" if prob >= 0.5 else "Low"

    risk_label = (
        f"High Risk of Heart Disease ({prob_percent}% probability)"
        if risk == "High"
        else f"Low Risk of Heart Disease ({prob_percent}% probability)"
    )

    return {
        "status": "success",
        "prediction": prediction,
        "risk": risk,
        "probability": round(prob, 4),
        "probability_percent": prob_percent,
        "label": risk_label,
        "feature_count_input": len(EXPECTED_INPUT_COLUMNS),
        "feature_count_processed": int(X_proc.shape[1]),
        "model_type": "Keras ANN (Sequential)",
        "inputs_received": input_data.model_dump(),
        "academic_disclaimer": "Academic prototype prediction. Not a certified medical diagnosis.",
    }


@app.post("/explain/clinical", summary="Explain Clinical Prediction with SHAP and LIME")
def explain_clinical(input_data: ClinicalInput):
    """
    Computes real SHAP values and LIME feature contributions for the given
    clinical input against the trained ANN model.
    """
    if state["model"] is None or state["preprocessor"] is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Clinical model or preprocessor not loaded.",
        )

    X_proc = prepare_features(input_data)

    raw_pred = state["model"].predict(X_proc, verbose=0)
    prob = float(raw_pred[0][0])
    risk = "High" if prob >= 0.5 else "Low"

    shap_results: List[Dict[str, Any]] = []
    lime_results: List[Dict[str, Any]] = []

    # 1. Real SHAP Explanation
    if state["shap_explainer"] is not None:
        try:
            s_vals = state["shap_explainer"].shap_values(X_proc, nsamples=40)
            if isinstance(s_vals, list):
                s_arr = s_vals[0]
            else:
                s_arr = s_vals

            flat_shap = np.array(s_arr).flatten()

            raw_shap_list = []
            for name, val in zip(state["feature_names"], flat_shap):
                raw_shap_list.append({
                    "label": name,
                    "value": round(abs(float(val)), 4),
                    "raw_value": round(float(val), 4),
                    "positive": bool(val > 0),
                })

            raw_shap_list.sort(key=lambda x: x["value"], reverse=True)
            shap_results = raw_shap_list[:10]
        except Exception as exc:
            logger.warning("SHAP calculation error: %s", exc)

    # 2. Real LIME Explanation
    if state["lime_explainer"] is not None:
        try:
            def predict_proba(x):
                p = state["model"].predict(x, verbose=0)
                return np.hstack([1 - p, p])

            exp = state["lime_explainer"].explain_instance(
                X_proc[0],
                predict_proba,
                num_features=8,
                num_samples=100,
            )

            lime_raw = exp.as_list()
            max_w = max([abs(w) for _, w in lime_raw]) if lime_raw else 1.0
            if max_w == 0:
                max_w = 1.0

            for rule_str, weight in lime_raw:
                clean_name = rule_str
                for feat in state["feature_names"]:
                    if feat in rule_str:
                        clean_name = feat
                        break

                pct_weight = int(round((abs(weight) / max_w) * 100))
                lime_results.append({
                    "name": clean_name,
                    "rule": rule_str,
                    "value": str(input_data.model_dump().get(clean_name, "active")),
                    "weight": pct_weight,
                    "raw_weight": round(float(weight), 4),
                    "positive": bool(weight > 0),
                })
        except Exception as exc:
            logger.warning("LIME calculation error: %s", exc)

    return {
        "status": "success",
        "prediction": 1 if prob >= 0.5 else 0,
        "risk": risk,
        "probability": round(prob, 4),
        "probability_percent": round(prob * 100, 2),
        "shap": shap_results,
        "lime": lime_results,
        "academic_disclaimer": "Academic prototype explanation. Demonstrates XAI on trained ANN.",
    }


# ---------------------------------------------------------------------
# SINGLE ECG BEAT INFERENCE & GRAD-CAM
# ---------------------------------------------------------------------

@app.post("/predict/ecg", summary="Predict Arrhythmia Class from Segmented ECG Heartbeat")
def predict_ecg(input_data: ECGHeartbeatInput):
    """
    Accepts an already segmented and normalized ECG heartbeat of shape (256, 2).
    Evaluates inference using the trained 1D-CNN model.
    Returns predicted class (0=Normal, 1=PVC), probabilities, and confidence score.
    """
    if state["ecg_model"] is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"ECG 1D-CNN model is not loaded. Error: {state['ecg_load_error']}",
        )

    signal_arr = np.array(input_data.signal, dtype=np.float32)  # shape (256, 2)
    x_input = np.expand_dims(signal_arr, axis=0)                # shape (1, 256, 2)

    try:
        raw_pred = state["ecg_model"].predict(x_input, verbose=0)
        pvc_prob = float(raw_pred[0][0])
    except Exception as exc:
        logger.error("ECG model inference error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"ECG model inference failed: {str(exc)}",
        )

    normal_prob = float(1.0 - pvc_prob)
    predicted_class = 1 if pvc_prob >= 0.5 else 0
    class_label = "PVC" if predicted_class == 1 else "Normal"
    confidence = pvc_prob if predicted_class == 1 else normal_prob

    return {
        "status": "success",
        "predicted_class": predicted_class,
        "class_label": class_label,
        "pvc_probability": round(pvc_prob, 4),
        "normal_probability": round(normal_prob, 4),
        "pvc_percent": round(pvc_prob * 100, 2),
        "normal_percent": round(normal_prob * 100, 2),
        "confidence": round(confidence, 4),
        "confidence_percent": round(confidence * 100, 2),
        "input_shape": list(signal_arr.shape),
        "model_type": state["ecg_metadata"].get("model_type", "Sequential 1D CNN"),
        "academic_disclaimer": "Academic research prototype. Not certified for clinical diagnosis.",
    }


@app.post("/explain/ecg", summary="Explain ECG Prediction with 1D Grad-CAM")
def explain_ecg(input_data: ECGExplanationInput):
    """
    Computes real 1D Grad-CAM activation heatmap for a segmented heartbeat of shape (256, 2)
    using the trained conv1d_2 convolutional layer.
    Supports explanations for both Normal and PVC classes.
    Returns exactly 256 activation values.
    """
    if state["ecg_model"] is None or state["ecg_grad_model"] is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"ECG 1D-CNN or Grad-CAM model is not loaded. Error: {state['ecg_load_error']}",
        )

    signal_arr = np.array(input_data.signal, dtype=np.float32)  # shape (256, 2)
    x_input = np.expand_dims(signal_arr, axis=0)

    try:
        raw_pred = state["ecg_model"].predict(x_input, verbose=0)
        pvc_prob = float(raw_pred[0][0])
    except Exception as exc:
        logger.error("ECG prediction error during explanation: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"ECG model evaluation failed: {str(exc)}",
        )

    predicted_class = 1 if pvc_prob >= 0.5 else 0
    predicted_label = "PVC" if predicted_class == 1 else "Normal"

    # Target class selection: specified or defaulted to predicted class
    if input_data.target_class is not None:
        target_class = int(input_data.target_class)
    else:
        target_class = predicted_class

    target_label = "PVC" if target_class == 1 else "Normal"

    try:
        gradcam_activations = compute_1d_gradcam(signal_arr, target_class)
    except Exception as exc:
        logger.error("1D Grad-CAM generation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"1D Grad-CAM generation failed: {str(exc)}",
        )

    return {
        "status": "success",
        "predicted_class": predicted_class,
        "predicted_label": predicted_label,
        "target_class": target_class,
        "target_label": target_label,
        "pvc_probability": round(pvc_prob, 4),
        "normal_probability": round(1.0 - pvc_prob, 4),
        "gradcam_layer": state["ecg_metadata"].get("gradcam_layer", "conv1d_2"),
        "gradcam_method": state["ecg_metadata"].get("gradcam_method", "1D Grad-CAM"),
        "activations_length": len(gradcam_activations),
        "gradcam_activations": gradcam_activations,
        "academic_disclaimer": "Academic prototype explanation. Demonstrates 1D Grad-CAM on trained ECG 1D-CNN.",
    }


# ---------------------------------------------------------------------
# RAW ECG RECORDING ANALYSIS PIPELINE (STAGE 2)
# ---------------------------------------------------------------------

@app.post("/ecg/analyze-recording", summary="Upload and Analyze MIT-BIH ECG Recording Files")
async def analyze_recording(
    dat_file: UploadFile = File(..., description="MIT-BIH ECG signal binary file (.dat)"),
    hea_file: UploadFile = File(..., description="MIT-BIH ECG header text file (.hea)"),
    atr_file: Optional[UploadFile] = File(None, description="Optional MIT-BIH ECG annotation file (.atr)"),
):
    """
    Accepts raw MIT-BIH record files (.dat, .hea, and optional .atr).
    Validates record pairing, applies Butterworth filtering, extracts heartbeats,
    runs 1D-CNN classification, computes real features, and returns complete analysis.
    """
    if not dat_file.filename.lower().endswith(".dat"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid signal file '{dat_file.filename}'. Must have a .dat extension.",
        )
    if not hea_file.filename.lower().endswith(".hea"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid header file '{hea_file.filename}'. Must have a .hea extension.",
        )

    dat_base = Path(dat_file.filename).stem
    hea_base = Path(hea_file.filename).stem

    if dat_base.lower() != hea_base.lower():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Mismatched record files: '{dat_file.filename}' and '{hea_file.filename}' belong to different records.",
        )

    has_atr = False
    if atr_file and atr_file.filename:
        if not atr_file.filename.lower().endswith(".atr"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid annotation file '{atr_file.filename}'. Must have a .atr extension.",
            )
        atr_base = Path(atr_file.filename).stem
        if atr_base.lower() != dat_base.lower():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Annotation file '{atr_file.filename}' does not match record name '{dat_base}'.",
            )
        has_atr = True

    record_name = dat_base

    # Write files into temporary directory safely
    with tempfile.TemporaryDirectory() as temp_dir_str:
        temp_dir = Path(temp_dir_str)
        dat_dest = temp_dir / f"{record_name}.dat"
        hea_dest = temp_dir / f"{record_name}.hea"

        with open(dat_dest, "wb") as f_out:
            shutil.copyfileobj(dat_file.file, f_out)

        with open(hea_dest, "wb") as f_out:
            shutil.copyfileobj(hea_file.file, f_out)

        if has_atr and atr_file:
            atr_dest = temp_dir / f"{record_name}.atr"
            with open(atr_dest, "wb") as f_out:
                shutil.copyfileobj(atr_file.file, f_out)

        # Process the recording
        analysis = process_ecg_dataset(temp_dir, record_name, has_atr=has_atr)

    return analysis


@app.post("/ecg/analyze-sample-100", summary="Analyze Built-in MIT-BIH Sample Record 100")
def analyze_sample_100():
    """
    Directly analyzes the built-in MIT-BIH record 100 files located at backend/sample_data/100.
    Allows 1-click end-to-end testing of raw ECG decoding, filtering, segmentation, and Grad-CAM.
    """
    if not (SAMPLE_DATA_DIR / "100.dat").exists() or not (SAMPLE_DATA_DIR / "100.hea").exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Built-in sample record 100 files not found in backend/sample_data.",
        )

    has_atr = (SAMPLE_DATA_DIR / "100.atr").exists()
    return process_ecg_dataset(SAMPLE_DATA_DIR, "100", has_atr=has_atr)


@app.get("/ecg/recording/{recording_id}", summary="Get Analysis Results for a Cached Recording")
def get_recording(recording_id: str):
    """Retrieve full analysis summary, features, and beat classifications for a cached recording."""
    if recording_id not in recording_cache:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Recording session '{recording_id}' not found or session has expired.",
        )
    return recording_cache[recording_id]["analysis_data"]


@app.get("/ecg/recording/{recording_id}/beats/{beat_index}", summary="Inspect Single Heartbeat & Grad-CAM")
def get_recording_beat(recording_id: str, beat_index: int):
    """
    Inspect a specific extracted heartbeat: returns the 256-sample raw signal,
    normalized signal, prediction, confidence, and real 1D Grad-CAM activations on conv1d_2.
    """
    if recording_id not in recording_cache:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Recording session '{recording_id}' not found.",
        )

    session = recording_cache[recording_id]
    analysis = session["analysis_data"]
    beats = analysis["beats"]

    if beat_index < 0 or beat_index >= len(beats):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Beat index {beat_index} out of range (0 to {len(beats) - 1}).",
        )

    beat_summary = beats[beat_index]
    norm_beat = session["norm_beats"][beat_index]
    raw_beat = session["raw_beats"][beat_index]

    # Compute 1D Grad-CAM for this specific beat
    gradcam_acts = compute_1d_gradcam(norm_beat, target_class=beat_summary["predicted_class"])

    return sanitize_for_json({
        "status": "success",
        "recording_id": recording_id,
        "record_name": analysis["record_name"],
        "beat_index": int(beat_index),
        "summary": beat_summary,
        "raw_signal": [list(np.round(pt, 4)) for pt in raw_beat.tolist()],
        "normalized_signal": [list(np.round(pt, 4)) for pt in norm_beat.tolist()],
        "gradcam_layer": "conv1d_2",
        "gradcam_activations": gradcam_acts,
        "lead_names": session["lead_names"],
        "academic_disclaimer": "Academic research prototype. Demonstrates 1D Grad-CAM on trained 1D-CNN.",
    })


@app.get("/ecg/recording/{recording_id}/signal", summary="Get Sliced Continuous ECG Signal")
def get_recording_signal(
    recording_id: str,
    start_sec: float = Query(0.0, ge=0.0, description="Start time in seconds"),
    duration_sec: float = Query(10.0, ge=1.0, le=60.0, description="Duration in seconds (1 - 60s)"),
):
    """Retrieve continuous ECG signal points for scrolling and viewing specific recording sections."""
    if recording_id not in recording_cache:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Recording session '{recording_id}' not found.",
        )

    session = recording_cache[recording_id]
    fs = session["fs"]
    filtered_sig = session["filtered_signal"]
    total_samples = len(filtered_sig)

    start_sample = int(start_sec * fs)
    end_sample = min(total_samples, int((start_sec + duration_sec) * fs))

    if start_sample >= total_samples:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Start time {start_sec}s exceeds recording duration {total_samples / fs:.1f}s.",
        )

    sliced = filtered_sig[start_sample:end_sample, :]
    times = [round(float((start_sample + i) / fs), 4) for i in range(len(sliced))]

    # Relevant R-peaks in this window
    r_peaks = [
        b for b in session["analysis_data"]["beats"]
        if start_sample <= b["r_peak_sample"] < end_sample
    ]

    return sanitize_for_json({
        "status": "success",
        "start_sec": float(start_sec),
        "duration_sec": float(duration_sec),
        "sampling_frequency": int(fs),
        "lead_names": session["lead_names"],
        "times": times,
        "lead_0": [round(float(v), 4) for v in sliced[:, 0]],
        "lead_1": [round(float(v), 4) for v in sliced[:, 1]],
        "r_peaks": r_peaks,
    })


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
