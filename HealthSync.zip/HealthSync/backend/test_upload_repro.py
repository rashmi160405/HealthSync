"""
Targeted test for POST /ecg/analyze-recording against live running server http://127.0.0.1:8000
Verifies:
1. File upload with .dat, .hea, and .atr
2. File upload with .dat and .hea ONLY (exercises algorithmic peak detection and verifies no numpy.int64 serialization failure)
3. Ensures valid HTTP 200 response with CORS headers
"""
import sys
import requests
from pathlib import Path

BASE_URL = "http://127.0.0.1:8000"
RECORD_DIR = Path(r"c:\Users\Rashmi M D\Downloads\files (1)\Major Project\HealthSync\backend\sample_data")

dat_path = RECORD_DIR / "100.dat"
hea_path = RECORD_DIR / "100.hea"
atr_path = RECORD_DIR / "100.atr"

print(f"Checking health at {BASE_URL}/health...")
r_health = requests.get(f"{BASE_URL}/health")
assert r_health.status_code == 200, f"Health check failed: {r_health.text}"
print(f"Health check OK: {r_health.json()['status']}")

# TEST 1: Upload with ATR
print("\n[TEST 1] Testing POST /ecg/analyze-recording WITH .atr...")
with open(dat_path, "rb") as f_dat, open(hea_path, "rb") as f_hea, open(atr_path, "rb") as f_atr:
    files = {
        "dat_file": ("100.dat", f_dat, "application/octet-stream"),
        "hea_file": ("100.hea", f_hea, "text/plain"),
        "atr_file": ("100.atr", f_atr, "application/octet-stream"),
    }
    headers = {"Origin": "http://localhost:8080"}
    resp = requests.post(f"{BASE_URL}/ecg/analyze-recording", files=files, headers=headers)

print(f"Response status: {resp.status_code}")
print(f"CORS header: Access-Control-Allow-Origin = {resp.headers.get('access-control-allow-origin')}")
assert resp.status_code == 200, f"Upload failed: {resp.text}"
data = resp.json()
print(f"Record: {data['record_name']}, beats: {data['features']['number_of_detected_beats']}")
print("Test 1 Passed!")

# TEST 2: Upload WITHOUT ATR (algorithmic peak detection)
print("\n[TEST 2] Testing POST /ecg/analyze-recording WITHOUT .atr (Algorithmic peak detection)...")
with open(dat_path, "rb") as f_dat, open(hea_path, "rb") as f_hea:
    files = {
        "dat_file": ("100.dat", f_dat, "application/octet-stream"),
        "hea_file": ("100.hea", f_hea, "text/plain"),
    }
    headers = {"Origin": "http://127.0.0.1:8080"}
    resp = requests.post(f"{BASE_URL}/ecg/analyze-recording", files=files, headers=headers)

print(f"Response status: {resp.status_code}")
print(f"CORS header: Access-Control-Allow-Origin = {resp.headers.get('access-control-allow-origin')}")
assert resp.status_code == 200, f"Upload without atr failed: {resp.text}"
data2 = resp.json()
print(f"Record: {data2['record_name']}, algorithmic beats: {data2['features']['number_of_detected_beats']}")
print(f"Annotation source: {data2['metadata']['annotation_source']}")
print("Test 2 Passed! Algorithmic peak detection and JSON serialization succeeded without numpy.int64 error!")

# TEST 3: Sample 100 1-click test
print("\n[TEST 3] Testing POST /ecg/analyze-sample-100...")
resp3 = requests.post(f"{BASE_URL}/ecg/analyze-sample-100", headers={"Origin": "http://localhost:8080"})
assert resp3.status_code == 200, f"Sample 100 failed: {resp3.text}"
print(f"Sample 100 OK! Status: {resp3.status_code}")

print("\n=======================================================")
print("ALL LIVE HTTP RECORDING UPLOAD TESTS PASSED SUCCESSFULLY!")
print("=======================================================")
