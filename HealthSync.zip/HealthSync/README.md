# HealthSync – Intelligent Healthcare | Explainable AI
### Academic Project Frontend Documentation

---

> **⚕️ Disclaimer:** HealthSync is an **academic prototype** built for research/coursework purposes.  
> All predictions are **simulated demo outputs**. This is **NOT** a certified medical diagnostic tool.  
> Never use this system for real medical diagnosis or treatment decisions.

---

## 📁 Project Structure

```
HealthSync/
├── index.html          # Main HTML – all 6 pages in one SPA
├── css/
│   └── styles.css      # Complete stylesheet (responsive, variables, components)
├── js/
│   └── app.js          # All JavaScript logic (navigation, forms, charts, storage)
└── README.md           # This file
```

---

## 🚀 How to Run

**Option 1 – Open directly in browser:**
```
Double-click  index.html   (or drag it into Chrome/Edge/Firefox)
```

**Option 2 – Local dev server (recommended for backend integration later):**
```bash
# Using Python
python -m http.server 8080

# Using Node.js (npx)
npx serve .
```
Then open `http://localhost:8080`

---

## 🔐 Demo Login Credentials

| Field    | Value                 |
|----------|-----------------------|
| Email    | `demo@healthsync.ac`  |
| Password | `Demo@1234`           |

> Click **"Auto-fill demo credentials"** on the login page for quick access.

---

## 📄 Pages Overview

| Page | Route (JS) | Description |
|------|-----------|-------------|
| **Login** | `navigate('login')` | Authentication gate with form validation |
| **Dashboard** | `navigate('dashboard')` | Welcome banner, 2 quick-action cards, stats, recent activity |
| **Clinical Prediction** | `navigate('clinical')` | 11-feature clinical form → risk prediction |
| **ECG Analysis** | `navigate('ecg')` | File upload, waveform visualisation, feature table |
| **Explainable AI** | `navigate('xai')` | SHAP bars, LIME tiles, Grad-CAM heatmap |
| **History** | `navigate('history')` | LocalStorage-backed history with search/filter/delete |

---

## 🏥 Clinical Form Features

| Field | Type | Range / Options |
|-------|------|-----------------|
| Age | Number | 1 – 120 years |
| Sex | Select | M / F |
| ChestPainType | Select | TA, ATA, NAP, ASY |
| RestingBP | Number | 60 – 250 mmHg |
| Cholesterol | Number | 100 – 600 mg/dL |
| FastingBS | Select | 0 (≤120) / 1 (>120) |
| RestingECG | Select | Normal, ST, LVH |
| MaxHR | Number | 50 – 220 bpm |
| ExerciseAngina | Select | Y / N |
| Oldpeak | Decimal | −5 to 10 |
| ST_Slope | Select | Up, Flat, Down |

All fields have **client-side validation** with clear error messages.

---

## 🔬 Explainable AI Panels (Simulated Demo)

### SHAP (SHapley Additive exPlanations)
- Horizontal bar chart showing feature contribution magnitude
- Navy bars = features that **increase** risk
- Teal bars = features that **decrease** risk
- Real SHAP requires: `pip install shap` + trained model

### LIME (Local Interpretable Model-agnostic Explanations)
- Tile grid showing each feature's value and impact weight
- Percentage bar shows relative influence
- Real LIME requires: `pip install lime` + trained model

### Grad-CAM (Gradient-weighted Class Activation Maps)
- Shows original ECG signal + activation heatmap overlay
- Red regions = high CNN attention, yellow = moderate, blue = low
- Real Grad-CAM requires: TensorFlow/PyTorch + trained 1D-CNN model

---

## 💾 LocalStorage History

- Every successful prediction is auto-saved to `localStorage` under key `healthsync_history`
- Max 50 records retained (FIFO)
- History page has **search** (by label/type), **filter** (all/clinical/ecg), and **delete per record**
- **Clear All** button with confirmation prompt
- No data leaves the browser — fully client-side

---

## 🎨 Design System

| Token | Value | Usage |
|-------|-------|-------|
| `--white` | `#FFFFFF` | Backgrounds, cards |
| `--bg-light` | `#F8FAFC` | Page background |
| `--navy-dark` | `#0F1E3C` | Sidebar, headings |
| `--navy` | `#1A2F5A` | Primary navy |
| `--navy-mid` | `#243B6E` | Gradient midpoint |
| `--teal-dark` | `#0D9488` | Primary teal, borders |
| `--teal` | `#14B8A6` | Buttons, accents |
| `--teal-light` | `#2DD4BF` | Hover states |
| `--teal-pale` | `#CCFBF1` | Light teal backgrounds |

**Typography:** Inter (Google Fonts) with system-ui fallback  
**Responsive:** 1024px tablet, 768px mobile, 480px small mobile breakpoints

---

## 🔧 Backend Integration Roadmap

> These features are **planned** but require Python/Flask backend:

| Feature | Backend Requirement |
|---------|---------------------|
| Real ML prediction | `scikit-learn` model, `joblib` serialisation |
| SHAP values | `shap` library, model explainer |
| LIME explanation | `lime` library, tabular explainer |
| ECG WFDB decoding | `wfdb`, `neurokit2` or `biosppy` |
| ECG classification | 1D-CNN model in TensorFlow/PyTorch |
| Real Grad-CAM | `tf-keras-vis` or PyTorch hooks |
| User authentication | Flask-Login + database (SQLite/PostgreSQL) |
| Data persistence | SQLite + SQLAlchemy ORM |

---

## 🛠 Technology Stack

| Layer | Technology |
|-------|-----------|
| Markup | HTML5 (semantic) |
| Styling | CSS3 (custom properties, Grid, Flexbox, animations) |
| Logic | Vanilla JavaScript ES6+ (no frameworks) |
| Storage | Web LocalStorage API |
| Charts | HTML5 Canvas API (ECG waveform, Grad-CAM) |
| Fonts | Google Fonts – Inter |

---

## 📋 Known Limitations (By Design)

1. **No real ML model** — all predictions are heuristic/random demo outputs
2. **No real ECG processing** — waveform is a synthesised sine-based demo
3. **No server** — runs as a static SPA, no data persistence beyond LocalStorage
4. **No real SHAP/LIME** — values are hardcoded demo arrays
5. **Single user** — credentials hardcoded for demo (replace with backend auth)

---

## 👩‍💻 Developer Notes

- All navigation is handled by `navigate(pageId)` in `app.js`
- Pages are CSS-hidden `<section>` elements toggled with the `active` class
- Form validation runs before any simulated API call
- Spinner shows during simulated processing delays (1.5–2.2 s)
- Toast notifications appear bottom-right for all user actions

---

*HealthSync · Academic Project · 2024*  
*Built with HTML, CSS, Vanilla JS · Explainable AI in Healthcare*
