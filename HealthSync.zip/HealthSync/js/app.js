/**
 * HealthSync – An Explainable AI-Based Cardiovascular Screening and ECG Arrhythmia Analysis Platform
 * Main Application JavaScript
 * Academic Prototype – Not for clinical use
 * Dataset: Heart Failure Prediction Dataset (Kaggle, fedesoriano) – 918 records, 11 features
 * ECG: MIT-BIH Arrhythmia Database – PVC vs Non-PVC (EfficientNetB0 + Transformer + Grad-CAM)
 */

'use strict';

/* =====================================================
   CONSTANTS & BACKEND CONFIGURATION
   ===================================================== */
const DEMO_USER = { email: 'demo@healthsync.ac', password: 'HealthSync#2026*Secure', name: 'Dr. Demo User', role: 'Researcher' };
const LS_KEY = 'healthsync_history';
const API_HOST = (typeof window !== 'undefined' && window.location.hostname && window.location.hostname !== '')
  ? window.location.hostname
  : '127.0.0.1';
const API_BASE_URL = `${typeof window !== 'undefined' && window.location.protocol === 'https:' ? 'https:' : 'http:'}//${API_HOST}:8000`;
let isBackendOnline = false;

function extractErrorMessage(err, fallback = 'Operation failed') {
  if (!err) return fallback;
  if (typeof err === 'string') return err;
  if (err.detail) {
    if (typeof err.detail === 'string') return err.detail;
    if (Array.isArray(err.detail)) {
      return err.detail.map(d => d.msg || JSON.stringify(d)).join('; ');
    }
    return JSON.stringify(err.detail);
  }
  if (err.message) {
    if (err.message === 'Failed to fetch') {
      return `Failed to connect to backend at ${API_BASE_URL}. Ensure the FastAPI server is running on port 8000.`;
    }
    return err.message;
  }
  return fallback;
}

/* =====================================================
   UTILITY FUNCTIONS
   ===================================================== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function showToast(message, type = 'info', duration = 3500) {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type]}</span><span>${message}</span>`;
  $('#toast-container').appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(100%)'; toast.style.transition = 'all 0.4s ease'; setTimeout(() => toast.remove(), 400); }, duration);
}

function showSpinner(label = 'Processing…', sub = 'Please wait a moment') {
  const ov = $('#spinner-overlay');
  $('#spinner-label').textContent = label;
  $('#spinner-sub').textContent = sub;
  ov.classList.remove('hidden');
}

function hideSpinner() { $('#spinner-overlay').classList.add('hidden'); }

function formatDate(date = new Date()) {
  return date.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function saveToHistory(entry) {
  const history = getHistory();
  history.unshift({ id: Date.now(), ...entry, date: formatDate() });
  localStorage.setItem(LS_KEY, JSON.stringify(history.slice(0, 50)));
}

function getHistory() {
  try { return JSON.parse(localStorage.getItem(LS_KEY)) || []; }
  catch { return []; }
}

/* =====================================================
   NAVIGATION & PAGE ROUTING
   ===================================================== */
let currentPage = 'login';
let isLoggedIn  = false;

function navigate(pageId) {
  /* Login page */
  if (pageId === 'login') {
    $('#page-login').classList.add('active');
    $('#app-shell').classList.remove('active');
    currentPage = 'login';
    document.title = 'HealthSync – Login';
    return;
  }

  if (!isLoggedIn) { navigate('login'); return; }

  /* Authenticated shell */
  $('#page-login').classList.remove('active');
  $('#app-shell').classList.add('active');

  /* Inner pages */
  $$('.inner-page').forEach(p => p.classList.remove('active'));
  const target = $(`#inner-${pageId}`);
  if (target) target.classList.add('active');

  /* Nav items */
  $$('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.page === pageId);
  });

  /* Page title map */
  const titles = {
    dashboard:   ['Dashboard', 'Overview & Quick Actions'],
    clinical:    ['Clinical Prediction', ''],
    ecg:         ['ECG Analysis', ''],
    xai:         ['Explainable AI Results', ''],
    history:     ['History', 'Past Analyses & Results'],
  };
  const t = titles[pageId] || [pageId, ''];
  $('#header-page-title').textContent   = t[0];
  $('#header-page-sub').textContent     = t[1];
  $('#header-page-sub').style.display   = t[1] ? 'block' : 'none';

  currentPage = pageId;
  document.title = `HealthSync – ${t[0]}`;

  /* Lazy renders */
  if (pageId === 'history')  renderHistory();
  if (pageId === 'xai')      initXAI();

  /* Mobile: close sidebar */
  $('#sidebar').classList.remove('open');
  $('#sidebar-overlay').classList.remove('show');

  window.scrollTo(0, 0);
}

/* =====================================================
   AUTH
   ===================================================== */
function handleLogin(e) {
  e.preventDefault();
  const email = $('#login-email').value.trim();
  const pass  = $('#login-pass').value;
  let valid   = true;

  clearErrors();

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showError('email-error', 'Enter a valid email address.'); valid = false;
  }
  if (!pass || pass.length < 6) {
    showError('pass-error', 'Password must be at least 6 characters.'); valid = false;
  }
  if (!valid) return;

  showSpinner('Authenticating…', 'Verifying your credentials');

  setTimeout(() => {
    hideSpinner();
    // Accept primary secure password, legacy demo password, or any valid credential for academic demo
    if (
      (email === DEMO_USER.email && (pass === DEMO_USER.password || pass === 'Demo@1234')) ||
      (email.includes('@') && pass.length >= 6)
    ) {
      isLoggedIn = true;
      const displayName = email === DEMO_USER.email ? DEMO_USER.name : (email.split('@')[0] || 'Clinician');
      $('#user-name-display').textContent   = displayName;
      $('#user-role-display').textContent   = DEMO_USER.role;
      $('#user-avatar-initials').textContent = displayName.slice(0, 2).toUpperCase();
      navigate('dashboard');
      showToast(`Welcome back, ${displayName}! 👋`, 'success');
    } else {
      showError('pass-error', 'Invalid email or password. Please check your credentials.');
      $('#login-pass').value = '';
    }
  }, 400);
}

function handleLogout() {
  isLoggedIn = false;
  navigate('login');
  showToast('Logged out successfully.', 'info');
}

function showError(id, msg) {
  const el = $(`#${id}`);
  if (el) { el.textContent = msg; el.classList.add('show'); }
}

function clearErrors() {
  $$('.error-msg').forEach(el => { el.textContent = ''; el.classList.remove('show'); });
}

/* Toggle password visibility */
function setupPasswordToggle() {
  const btn   = $('#toggle-pass-btn');
  const input = $('#login-pass');
  if (!btn || !input) return;
  btn.addEventListener('click', () => {
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.textContent = show ? '🙈' : '👁️';
  });
}

/* Auto-fill demo credentials */
function fillDemo() {
  $('#login-email').value = DEMO_USER.email;
  $('#login-pass').value  = DEMO_USER.password;
  clearErrors();
  $('#login-form').dispatchEvent(new Event('submit'));
}

/* =====================================================
   DASHBOARD
   ===================================================== */
function updateDashboardStats() {
  const history = getHistory();
  $('#stat-total').textContent    = history.length;
  $('#stat-clinical').textContent = history.filter(h => h.type === 'clinical').length;
  $('#stat-ecg').textContent      = history.filter(h => h.type === 'ecg').length;

  /* Recent activity on dashboard */
  renderDashActivity(history.slice(0, 4));
}

function renderDashActivity(items) {
  const list = $('#dash-activity-list');
  if (!list) return;

  if (items.length === 0) {
    list.innerHTML = `<div class="dash-empty-state">
      <p style="margin:0">No analysis records yet. Run a Clinical Prediction or ECG Analysis to see records here.</p>
    </div>`;
    return;
  }

  list.innerHTML = items.map(item => {
    const isEcg = item.type === 'ecg';
    const iconSvg = isEcg
      ? `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0D9488" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>`
      : `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0D9488" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l1.5-3 2 6 1.5-3h6.28"/></svg>`;
    
    const displayLabel = isEcg ? 'ECG Upload' : (item.label || 'Clinical Prediction');
    const metaText = item.date + (isEcg ? ' · No signal decoded' : (item.prob !== undefined ? ` · ${item.prob}% score` : ' · Completed'));
    const badgeText = item.risk || (isEcg ? 'Demo' : 'Done');

    return `
      <div class="dash-activity-card">
        <div class="dash-act-left">
          <div class="dash-act-icon" style="background:#F0FDFA;">
            ${iconSvg}
          </div>
          <div class="dash-act-info">
            <div class="dash-act-title">${displayLabel}</div>
            <div class="dash-act-meta">${metaText}</div>
          </div>
        </div>
        <span class="dash-act-badge">${badgeText}</span>
      </div>`;
  }).join('');
}

/* =====================================================
   BACKEND CONNECTION & STATUS MONITOR
   ===================================================== */
async function checkBackendStatus() {
  const badge = $('#api-status-badge');
  const dot   = $('#api-status-dot');
  const text  = $('#api-status-text');
  if (!badge || !dot || !text) return false;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);
    const res = await fetch(`${API_BASE_URL}/health`, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (data.status === 'healthy') {
      isBackendOnline = true;
      badge.classList.remove('offline');
      dot.classList.remove('offline');
      text.textContent = ' ';
      badge.title = 'Prediction models and preprocessing pipeline loaded successfully.';
      return true;
    } else {
      throw new Error(data.load_error || 'Model degraded');
    }
  } catch (err) {
    isBackendOnline = false;
    badge.classList.add('offline');
    dot.classList.add('offline');
    text.textContent = 'Backend Offline';
    badge.title = `Cannot connect to ${API_BASE_URL}. Ensure the FastAPI server is running.`;
    return false;
  }
}

/* =====================================================
   CLINICAL PREDICTION FORM (REAL ANN INTEGRATION)
   ===================================================== */
let lastClinicalResult = null;

function setupClinicalForm() {
  const form = $('#clinical-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateClinicalForm()) return;

    // 1. Gather all 11 clinical features mapped to dataset schema
    const payload = {
      Age:            parseInt($('#age').value, 10),
      Sex:            $('#sex').value,
      ChestPainType:  $('#chest-pain').value,
      RestingBP:      parseFloat($('#restingbp').value),
      Cholesterol:    parseFloat($('#chol').value),
      FastingBS:      parseInt($('#fasting-bs').value, 10),
      RestingECG:      $('#resting-ecg').value,
      MaxHR:          parseFloat($('#maxhr').value),
      ExerciseAngina: $('#exercise-angina').value,
      Oldpeak:        parseFloat($('#oldpeak').value),
      ST_Slope:       $('#st-slope').value,
    };

    // 2. Show loading spinner
    showSpinner('Evaluating Risk Profile…', 'Analyzing patient clinical risk factors');

    try {
      // 3. Request real prediction from FastAPI backend
      const response = await fetch(`${API_BASE_URL}/predict/clinical`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        const detailMsg = errJson.detail
          ? (typeof errJson.detail === 'string' ? errJson.detail : JSON.stringify(errJson.detail))
          : `Server error HTTP ${response.status}`;
        throw new Error(detailMsg);
      }

      const result = await response.json();
      lastClinicalResult = result;
      window._lastClinicalResult = result;
      window._lastPayload = payload;

      // 4. Request real Explainable AI data (SHAP & LIME) in parallel
      try {
        const expResponse = await fetch(`${API_BASE_URL}/explain/clinical`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (expResponse.ok) {
          window._lastXAIResult = await expResponse.json();
        }
      } catch (xaiErr) {
        console.warn('XAI calculation notice:', xaiErr);
      }

      hideSpinner();

      // 5. Display real prediction result on UI
      displayClinicalResult(result);

      // 6. Save real prediction to LocalStorage history
      saveToHistory({
        type:  'clinical',
        label: `Prediction Model: ${result.risk} Risk (${result.probability_percent}%)`,
        risk:  result.risk,
        prob:  result.probability_percent,
        details: payload,
      });

      updateDashboardStats();
      showToast(`Prediction complete: ${result.risk} Risk (${result.probability_percent}% probability).`, 'success');
      checkBackendStatus();
    } catch (error) {
      hideSpinner();
      displayClinicalError(error.message);
      showToast(`Prediction request failed: ${error.message}`, 'error', 6000);
      checkBackendStatus();
    }
  });

  form.addEventListener('reset', () => {
    $('#clinical-result-section').classList.add('hidden');
    clearClinicalErrors();
  });
}

function validateClinicalForm() {
  clearClinicalErrors();
  let valid = true;

  const rules = [
    { id: 'age',       min: 1,   max: 120, label: 'Age' },
    { id: 'restingbp', min: 60,  max: 250, label: 'Resting BP' },
    { id: 'chol',      min: 0,   max: 600, label: 'Cholesterol' },
    { id: 'maxhr',     min: 50,  max: 220, label: 'Max HR' },
    { id: 'oldpeak',   min: -5,  max: 10,  label: 'Oldpeak', isFloat: true },
  ];

  rules.forEach(r => {
    const el  = $(`#${r.id}`);
    const val = r.isFloat ? parseFloat(el.value) : parseInt(el.value, 10);
    if (!el.value || isNaN(val) || val < r.min || val > r.max) {
      markFieldError(el, `${r.label}: enter a valid number between ${r.min} and ${r.max}.`);
      valid = false;
    }
  });

  const selects = ['sex', 'chest-pain', 'fasting-bs', 'resting-ecg', 'exercise-angina', 'st-slope'];
  selects.forEach(id => {
    const el = $(`#${id}`);
    if (!el.value) { markFieldError(el, 'Please select an option.'); valid = false; }
  });

  return valid;
}

function markFieldError(el, msg) {
  el.classList.add('error');
  const errEl = el.closest('.form-group')?.querySelector('.error-msg');
  if (errEl) { errEl.textContent = msg; errEl.classList.add('show'); }
}

function clearClinicalErrors() {
  $$('#clinical-form .form-input, #clinical-form .form-select').forEach(el => el.classList.remove('error'));
  $$('#clinical-form .error-msg').forEach(el => { el.textContent = ''; el.classList.remove('show'); });
}

function displayClinicalResult(result) {
  const section = $('#clinical-result-section');
  if (!section) return;
  section.classList.remove('hidden');
  section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  // Update tag to show prediction model
  const tag = $('#clinical-result-tag');
  if (tag) {
    tag.textContent = 'Prediction Model';
    tag.style.background = '#ECFDF5';
    tag.style.color = '#065F46';
    tag.style.borderColor = '#A7F3D0';
  }

  // Update model info box
  const infoBox = $('#clinical-model-info-box');
  if (infoBox) {
    infoBox.style.background = '#F0FDF4';
    infoBox.style.border = '1px solid #86EFAC';
    infoBox.style.borderLeft = '4px solid #16A34A';
    infoBox.style.color = '#166534';
    infoBox.innerHTML = `<strong>✅ Prediction Generated Successfully</strong>`;
  }

  // Update result banner
  const banner = $('#result-banner');
  if (banner) {
    banner.className = `result-banner ${result.risk === 'High' ? 'high-risk' : 'low-risk'}`;
    banner.style.background = '';
    banner.style.border = '';
  }
  const icon = $('#result-icon');
  if (icon) icon.textContent = result.risk === 'High' ? '⚠️' : '✅';

  const title = $('#result-title');
  if (title) title.textContent = `${result.risk} Risk of Cardiovascular Disease`;

  const desc = $('#result-desc');
  if (desc) {
    desc.textContent = `Cardiovascular risk evaluation indicates a ${result.risk.toLowerCase()} probability of cardiovascular disease based on the provided clinical metrics.`;
  }

  const prob = $('#result-prob');
  if (prob) prob.textContent = `${result.probability_percent}%`;

  const probLabel = $('#result-prob-label');
  if (probLabel) probLabel.textContent = 'Estimated Probability';

  const barTitle = $('#prob-bar-title');
  if (barTitle) barTitle.textContent = 'Estimated Probability';

  const probVal = $('#result-prob-val');
  if (probVal) probVal.textContent = `${result.probability_percent}%`;

  const fill = $('#result-prob-fill');
  if (fill) {
    fill.style.width = `${Math.min(100, Math.max(3, result.probability_percent))}%`;
    fill.style.background = result.risk === 'High'
      ? 'linear-gradient(90deg, #DC2626, #EF4444)'
      : 'linear-gradient(90deg, #16A34A, #22C55E)';
  }

  const disclaimer = $('#clinical-disclaimer-text');
  if (disclaimer) {
    disclaimer.innerHTML = `⚠️ <strong>Academic Prototype:</strong> This prediction is generated by an academic research prototype and is <strong>not</strong> a certified clinical diagnosis. Always consult a licensed physician.`;
  }

  // Store for XAI page
  window._lastClinicalResult = result;
}

function displayClinicalError(errorMsg) {
  const section = $('#clinical-result-section');
  if (!section) return;
  section.classList.remove('hidden');
  section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  const tag = $('#clinical-result-tag');
  if (tag) {
    tag.textContent = '❌ Backend Connection Error';
    tag.style.background = '#FEE2E2';
    tag.style.color = '#DC2626';
    tag.style.borderColor = '#FCA5A5';
  }

  const infoBox = $('#clinical-model-info-box');
  if (infoBox) {
    infoBox.style.background = '#FEF2F2';
    infoBox.style.border = '1px solid #FCA5A5';
    infoBox.style.borderLeft = '4px solid #DC2626';
    infoBox.style.color = '#991B1B';
    infoBox.innerHTML = `<strong>⚠️ Could not reach Python FastAPI backend:</strong><br/>
    The website attempted to connect to <code>${API_BASE_URL}/predict/clinical</code>, but the server was unreachable.<br/><br/>
    <strong>How to resolve:</strong><br/>
    1. Open a PowerShell/terminal window.<br/>
    2. Run the command: <code>.\\backend\\.venv\\Scripts\\python.exe -m uvicorn backend.main:app --port 8000</code><br/>
    3. Ensure the backend status pill in the top header turns green.<br/>
    4. Click <strong>Run Prediction</strong> again.`;
  }

  const banner = $('#result-banner');
  if (banner) {
    banner.className = 'result-banner';
    banner.style.background = '#FEF2F2';
    banner.style.border = '1px solid #FCA5A5';
  }

  const icon = $('#result-icon');
  if (icon) icon.textContent = '❌';

  const title = $('#result-title');
  if (title) title.textContent = 'Prediction Request Failed';

  const desc = $('#result-desc');
  if (desc) desc.textContent = errorMsg || 'Backend is currently offline or unreachable.';

  const prob = $('#result-prob');
  if (prob) prob.textContent = '—';

  const probVal = $('#result-prob-val');
  if (probVal) probVal.textContent = 'Failed';

  const fill = $('#result-prob-fill');
  if (fill) {
    fill.style.width = '0%';
  }
}

/* =====================================================
   ECG ANALYSIS PAGE (STAGE 2 REAL WFDB & 1D GRAD-CAM)
   ===================================================== */
let currentECGFiles = { dat: null, hea: null, atr: null };
let currentECGAnalysis = null;
let currentLeadIndex = 0; // 0 for Lead 1 (MLII), 1 for Lead 2 (V5)
let currentBeatFilter = 'all'; // 'all', 'pvc', 'normal'
let activeInspectedBeatIndex = 0;

function setupECGPage() {
  const zone = $('#ecg-upload-zone');
  const fileInput = $('#ecg-file-input');
  if (!zone || !fileInput) return;

  zone.addEventListener('click', () => fileInput.click());

  zone.addEventListener('dragover', (e) => {
    e.preventDefault();
    zone.classList.add('drag-over');
  });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleECGFiles(Array.from(e.dataTransfer.files));
    }
  });

  fileInput.addEventListener('change', () => {
    if (fileInput.files && fileInput.files.length > 0) {
      handleECGFiles(Array.from(fileInput.files));
    }
  });

  // Action buttons
  const analyzeBtn = $('#ecg-analyze-btn');
  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', analyzeUploadedECG);
  }

  const loadSampleBtn = $('#ecg-load-sample-btn');
  if (loadSampleBtn) {
    loadSampleBtn.addEventListener('click', analyzeSampleRecord100);
  }

  // Lead channel toggle
  const lead0Btn = $('#lead-toggle-0');
  const lead1Btn = $('#lead-toggle-1');
  if (lead0Btn && lead1Btn) {
    lead0Btn.addEventListener('click', () => {
      currentLeadIndex = 0;
      lead0Btn.classList.add('active');
      lead1Btn.classList.remove('active');
      if (currentECGAnalysis) renderContinuousWaveform(currentECGAnalysis, currentLeadIndex);
    });
    lead1Btn.addEventListener('click', () => {
      currentLeadIndex = 1;
      lead1Btn.classList.add('active');
      lead0Btn.classList.remove('active');
      if (currentECGAnalysis) renderContinuousWaveform(currentECGAnalysis, currentLeadIndex);
    });
  }

  // Beat filter buttons
  const filterAll = $('#beat-filter-all');
  const filterPVC = $('#beat-filter-pvc');
  const filterNormal = $('#beat-filter-normal');
  if (filterAll && filterPVC && filterNormal) {
    filterAll.addEventListener('click', () => setBeatFilter('all'));
    filterPVC.addEventListener('click', () => setBeatFilter('pvc'));
    filterNormal.addEventListener('click', () => setBeatFilter('normal'));
  }

  // Beat selector dropdown
  const beatDropdown = $('#beat-selector-dropdown');
  if (beatDropdown) {
    beatDropdown.addEventListener('change', (e) => {
      const idx = parseInt(e.target.value, 10);
      if (!isNaN(idx)) inspectBeat(idx);
    });
  }

  drawECGPlaceholder();
}

function handleECGFiles(files) {
  const statusBox = $('#ecg-files-status-box');
  const analyzeBtn = $('#ecg-analyze-btn');
  const msgEl = $('#ecg-upload-msg');

  files.forEach(f => {
    const ext = f.name.split('.').pop().toLowerCase();
    if (ext === 'dat') currentECGFiles.dat = f;
    else if (ext === 'hea') currentECGFiles.hea = f;
    else if (ext === 'atr') currentECGFiles.atr = f;
  });

  const hasDat = !!currentECGFiles.dat;
  const hasHea = !!currentECGFiles.hea;
  const hasAtr = !!currentECGFiles.atr;

  let datBase = hasDat ? currentECGFiles.dat.name.replace(/\.[^/.]+$/, '') : '';
  let heaBase = hasHea ? currentECGFiles.hea.name.replace(/\.[^/.]+$/, '') : '';
  const namesMatch = hasDat && hasHea && (datBase.toLowerCase() === heaBase.toLowerCase());

  let html = '';
  if (hasDat) {
    html += `
      <div class="ecg-file-badge valid">
        <span>📄 <strong>${currentECGFiles.dat.name}</strong> (Binary Signal, ${(currentECGFiles.dat.size / 1024).toFixed(1)} KB)</span>
        <span>✅ Signal File Loaded</span>
      </div>`;
  } else {
    html += `
      <div class="ecg-file-badge missing">
        <span>⚠️ <strong>Missing .dat file</strong></span>
        <span>Required: MIT-BIH Signal file (.dat)</span>
      </div>`;
  }

  if (hasHea) {
    html += `
      <div class="ecg-file-badge valid">
        <span>📋 <strong>${currentECGFiles.hea.name}</strong> (Header, ${(currentECGFiles.hea.size / 1024).toFixed(1)} KB)</span>
        <span>✅ Header File Loaded</span>
      </div>`;
  } else {
    html += `
      <div class="ecg-file-badge missing">
        <span>⚠️ <strong>Missing .hea file</strong></span>
        <span>Required: MIT-BIH Header file (.hea)</span>
      </div>`;
  }

  if (hasAtr) {
    html += `
      <div class="ecg-file-badge valid">
        <span>🏷️ <strong>${currentECGFiles.atr.name}</strong> (Annotations, ${(currentECGFiles.atr.size / 1024).toFixed(1)} KB)</span>
        <span>✅ Annotation File Loaded (Optional)</span>
      </div>`;
  }

  if (statusBox) {
    statusBox.innerHTML = html;
    statusBox.classList.remove('hidden');
  }

  if (hasDat && hasHea && namesMatch) {
    analyzeBtn.disabled = false;
    if (msgEl) {
      msgEl.innerHTML = `<span style="color:#16A34A;font-weight:600">✅ Ready to analyze:</span> Record <code>${datBase}</code> files paired successfully. Click <strong>Analyze Uploaded Recording</strong> to proceed.`;
    }
    showToast(`Record ${datBase} files loaded successfully.`, 'info');
  } else if (hasDat && hasHea && !namesMatch) {
    analyzeBtn.disabled = true;
    if (msgEl) {
      msgEl.innerHTML = `<span style="color:#DC2626;font-weight:600">❌ Mismatched records:</span> '${currentECGFiles.dat.name}' and '${currentECGFiles.hea.name}' have different base names.`;
    }
  } else {
    analyzeBtn.disabled = true;
    if (msgEl) {
      msgEl.innerHTML = `Please ensure both <strong>.dat</strong> and <strong>.hea</strong> files for the record are selected together.`;
    }
  }
}

async function analyzeUploadedECG() {
  if (!currentECGFiles.dat || !currentECGFiles.hea) return;

  const formData = new FormData();
  formData.append('dat_file', currentECGFiles.dat);
  formData.append('hea_file', currentECGFiles.hea);
  if (currentECGFiles.atr) {
    formData.append('atr_file', currentECGFiles.atr);
  }

  showSpinner('Analyzing Raw MIT-BIH ECG Recording…', 'Decoding WFDB signal, applying Butterworth filter, segmenting heartbeats, and running 1D-CNN inference');

  try {
    const response = await fetch(`${API_BASE_URL}/ecg/analyze-recording`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      let errData;
      try { errData = await response.json(); } catch (_) { errData = { detail: await response.text() }; }
      throw new Error(extractErrorMessage(errData, `Server responded with HTTP ${response.status}`));
    }

    const result = await response.json();
    hideSpinner();
    displayECGAnalysisResult(result);
    showToast(`ECG Analysis Complete: ${result.features.number_of_detected_beats} beats classified.`, 'success');
  } catch (err) {
    hideSpinner();
    showToast(`ECG Analysis Failed: ${extractErrorMessage(err)}`, 'error', 6000);
    console.error('ECG Analysis error:', err);
  }
}

async function analyzeSampleRecord100() {
  showSpinner('Analyzing Built-in MIT-BIH Record 100…', 'Decoding 100.dat & 100.hea with WFDB, 4th-order Butterworth bandpass (0.5-40 Hz), batch 1D-CNN evaluation');

  try {
    const response = await fetch(`${API_BASE_URL}/ecg/analyze-sample-100`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      let errData;
      try { errData = await response.json(); } catch (_) { errData = { detail: await response.text() }; }
      throw new Error(extractErrorMessage(errData, `Server responded with HTTP ${response.status}`));
    }

    const result = await response.json();
    hideSpinner();
    displayECGAnalysisResult(result);
    showToast(`Record 100 Analysis Complete: ${result.features.number_of_detected_beats} beats processed.`, 'success');
  } catch (err) {
    hideSpinner();
    showToast(`Failed to analyze Record 100: ${extractErrorMessage(err)}`, 'error', 6000);
    console.error('Record 100 error:', err);
  }
}

function displayECGAnalysisResult(result) {
  currentECGAnalysis = result;
  window._lastECGAnalysis = result;

  const container = $('#ecg-results-container');
  if (container) {
    container.classList.remove('hidden');
    container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  // 1. Metadata
  const meta = result.metadata;
  if ($('#meta-record-name')) $('#meta-record-name').textContent = result.record_name;
  if ($('#meta-sampling-rate')) $('#meta-sampling-rate').textContent = `${meta.sampling_frequency} Hz`;
  if ($('#meta-leads')) $('#meta-leads').textContent = `${meta.number_of_channels} (${meta.lead_names.join(', ')})`;
  if ($('#meta-duration')) $('#meta-duration').textContent = `${meta.duration_formatted} (${meta.total_samples.toLocaleString()} samples)`;
  if ($('#meta-annotation-source')) $('#meta-annotation-source').textContent = meta.annotation_source;

  // 2. Computed Features
  const feats = result.features;
  if ($('#feat-hr')) $('#feat-hr').innerHTML = `${feats.heart_rate_bpm} <span style="font-size:0.9rem">bpm</span>`;
  if ($('#feat-hr-sub')) $('#feat-hr-sub').textContent = `Mean RR: ${feats.mean_rr_ms} ms`;

  if ($('#feat-sdnn')) $('#feat-sdnn').innerHTML = `${feats.sdnn_ms} <span style="font-size:0.9rem">ms</span>`;
  if ($('#feat-rr-range')) $('#feat-rr-range').textContent = `Range: ${feats.min_rr_ms} – ${feats.max_rr_ms} ms`;

  if ($('#feat-qrs')) $('#feat-qrs').innerHTML = `${feats.qrs_duration_ms || '—'} <span style="font-size:0.9rem">ms</span>`;
  if ($('#feat-qrs-sub')) $('#feat-qrs-sub').textContent = feats.qrs_measurement_method;

  if ($('#feat-pvc-count')) $('#feat-pvc-count').innerHTML = `${feats.pvc_beat_count} <span style="font-size:0.9rem">PVCs</span>`;
  if ($('#feat-pvc-sub')) $('#feat-pvc-sub').textContent = `${feats.pvc_percentage}% of ${feats.number_of_detected_beats} beats`;

  const pvcCard = $('#feat-pvc-card');
  if (pvcCard) {
    if (feats.pvc_beat_count > 0) pvcCard.classList.add('highlight');
    else pvcCard.classList.remove('highlight');
  }

  // Features table
  if ($('#table-feat-hr')) $('#table-feat-hr').textContent = `${feats.heart_rate_bpm} bpm`;
  if ($('#table-feat-rr')) $('#table-feat-rr').textContent = `${feats.mean_rr_ms} ms (Min: ${feats.min_rr_ms} ms, Max: ${feats.max_rr_ms} ms)`;
  if ($('#table-feat-sdnn')) $('#table-feat-sdnn').textContent = `${feats.sdnn_ms} ms`;
  if ($('#table-feat-qrs')) $('#table-feat-qrs').textContent = feats.qrs_duration_ms ? `${feats.qrs_duration_ms} ms` : 'Not measurable';
  if ($('#table-feat-qrs-note')) $('#table-feat-qrs-note').textContent = feats.qrs_measurement_method;
  if ($('#table-feat-total-beats')) $('#table-feat-total-beats').textContent = `${feats.number_of_detected_beats.toLocaleString()} beats`;
  if ($('#table-feat-normal-beats')) $('#table-feat-normal-beats').textContent = `${feats.normal_beat_count.toLocaleString()} (${(100 - feats.pvc_percentage).toFixed(1)}%)`;
  if ($('#table-feat-pvc-beats')) {
    $('#table-feat-pvc-beats').innerHTML = feats.pvc_beat_count > 0
      ? `<span style="color:#DC2626;font-weight:700">${feats.pvc_beat_count} (${feats.pvc_percentage}%)</span>`
      : `<span style="color:#16A34A;font-weight:700">0 (0.0%)</span>`;
  }
  if ($('#table-feat-rhythm-assessment')) $('#table-feat-rhythm-assessment').textContent = feats.overall_classification;

  // 3. Render continuous waveform
  renderContinuousWaveform(result, currentLeadIndex);

  // 4. Populate Beat Selector Dropdown
  const dropdown = $('#beat-selector-dropdown');
  if (dropdown) {
    dropdown.innerHTML = result.beats.slice(0, 100).map(b => `
      <option value="${b.beat_index}">Beat #${b.beat_index} (${b.class_label} @ ${b.time_sec}s)</option>
    `).join('');
  }

  // 5. Populate Beat Table
  renderBeatTable(result.beats, currentBeatFilter);

  // 6. Inspect initial beat (favor first PVC if present, otherwise beat 0)
  const initialInspectIdx = (result.first_pvc_gradcam && result.first_pvc_gradcam.beat_index !== undefined)
    ? result.first_pvc_gradcam.beat_index
    : 0;

  inspectBeat(initialInspectIdx);

  // Save to History
  saveToHistory({
    type: 'ecg',
    label: `ECG Record ${result.record_name} (${feats.number_of_detected_beats} beats, ${feats.pvc_beat_count} PVCs)`,
    risk: feats.pvc_beat_count > 0 ? 'Arrhythmia Detected' : 'Normal Rhythm',
  });
  updateDashboardStats();
}

function renderContinuousWaveform(result, leadIdx) {
  const canvas = $('#ecg-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  canvas.width = canvas.parentElement.offsetWidth || 800;
  canvas.height = 180;
  const w = canvas.width;
  const h = canvas.height;

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#0F1E3C';
  ctx.fillRect(0, 0, w, h);

  // Draw ECG grid (medical style grid)
  ctx.strokeStyle = 'rgba(20, 184, 166, 0.12)';
  ctx.lineWidth = 0.5;
  for (let x = 0; x < w; x += 20) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }
  for (let y = 0; y < h; y += 20) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }

  const cont = result.continuous_signal;
  const signal = leadIdx === 0 ? cont.lead_0 : cont.lead_1;
  if (!signal || signal.length === 0) return;

  const nPoints = signal.length;
  const minVal = -1.5;
  const maxVal = 2.0;
  const midY = h / 2;
  const scaleY = (h * 0.75) / (maxVal - minVal);

  // Draw actual continuous waveform
  ctx.beginPath();
  ctx.strokeStyle = leadIdx === 0 ? '#14B8A6' : '#60A5FA';
  ctx.lineWidth = 1.75;

  for (let i = 0; i < nPoints; i++) {
    const x = (i / nPoints) * w;
    const y = midY - (signal[i] * scaleY);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Overlay detected R-peaks
  const excerptSamples = cont.excerpt_duration_seconds * cont.sampling_frequency;
  cont.r_peaks.forEach(p => {
    if (p.r_peak_sample < excerptSamples) {
      const px = (p.r_peak_sample / excerptSamples) * w;
      const sampleVal = signal[p.r_peak_sample] !== undefined ? signal[p.r_peak_sample] : 0.8;
      const py = midY - (sampleVal * scaleY);

      // Marker circle
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, 2 * Math.PI);
      ctx.fillStyle = p.class_label === 'PVC' ? '#EF4444' : '#10B981';
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Label
      ctx.fillStyle = p.class_label === 'PVC' ? '#FCA5A5' : '#86EFAC';
      ctx.font = 'bold 9px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(p.class_label === 'PVC' ? 'PVC' : 'N', px, Math.max(14, py - 8));
    }
  });

  const winLabel = $('#ecg-canvas-window-label');
  if (winLabel) {
    winLabel.textContent = `Showing Lead: ${cont.lead_names[leadIdx]} (0.0s – ${cont.excerpt_duration_seconds}s)`;
  }
}

function setBeatFilter(filterType) {
  currentBeatFilter = filterType;
  $$('#beat-filter-all, #beat-filter-pvc, #beat-filter-normal').forEach(b => b.classList.remove('active'));
  if (filterType === 'all') $('#beat-filter-all')?.classList.add('active');
  else if (filterType === 'pvc') $('#beat-filter-pvc')?.classList.add('active');
  else if (filterType === 'normal') $('#beat-filter-normal')?.classList.add('active');

  if (currentECGAnalysis) {
    renderBeatTable(currentECGAnalysis.beats, filterType);
  }
}

function renderBeatTable(beats, filterType) {
  const tbody = $('#beat-table-tbody');
  const countLabel = $('#beat-table-count-label');
  if (!tbody) return;

  let filtered = beats;
  if (filterType === 'pvc') {
    filtered = beats.filter(b => b.predicted_class === 1);
  } else if (filterType === 'normal') {
    filtered = beats.filter(b => b.predicted_class === 0);
  }

  if (countLabel) {
    countLabel.textContent = `Displaying ${Math.min(100, filtered.length)} of ${filtered.length} beats (Filter: ${filterType.toUpperCase()})`;
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:1.5rem;color:var(--text-muted)">No beats matched the selected filter (${filterType}).</td></tr>`;
    return;
  }

  // Display top 100 matching beats for smooth DOM performance
  tbody.innerHTML = filtered.slice(0, 100).map(b => {
    const isPVC = b.predicted_class === 1;
    const tagCls = isPVC ? 'pvc' : 'normal';
    const rowCls = b.beat_index === activeInspectedBeatIndex ? 'active-beat-row' : '';

    return `
      <tr class="${rowCls}" data-beat-index="${b.beat_index}">
        <td><strong>#${b.beat_index}</strong></td>
        <td>${b.time_sec.toFixed(3)}s</td>
        <td><code>${b.r_peak_sample}</code></td>
        <td><span class="beat-tag ${tagCls}">${b.class_label}</span></td>
        <td>${b.pvc_percent.toFixed(2)}%</td>
        <td>${b.confidence_percent.toFixed(2)}%</td>
        <td><code style="font-weight:700">${b.wfdb_annotation || '—'}</code></td>
        <td>
          <button class="beat-inspect-btn" onclick="inspectBeat(${b.beat_index})">
            🔍 Inspect
          </button>
        </td>
      </tr>`;
  }).join('');

  // Add click listener to row
  $$('#beat-table-tbody tr').forEach(row => {
    row.addEventListener('click', (e) => {
      if (e.target.tagName !== 'BUTTON') {
        const idx = parseInt(row.dataset.beatIndex, 10);
        if (!isNaN(idx)) inspectBeat(idx);
      }
    });
  });
}

async function inspectBeat(beatIndex) {
  if (!currentECGAnalysis) return;
  activeInspectedBeatIndex = beatIndex;

  // Highlight active row in table
  $$('#beat-table-tbody tr').forEach(tr => {
    if (parseInt(tr.dataset.beatIndex, 10) === beatIndex) tr.classList.add('active-beat-row');
    else tr.classList.remove('active-beat-row');
  });

  // Sync dropdown
  const dropdown = $('#beat-selector-dropdown');
  if (dropdown) dropdown.value = beatIndex;

  try {
    const response = await fetch(`${API_BASE_URL}/ecg/recording/${currentECGAnalysis.recording_id}/beats/${beatIndex}`);
    if (!response.ok) throw new Error('Could not fetch beat details');
    const beatData = await response.json();

    renderBeatGradCAMInspector(beatData);
    window._lastECGBeat = beatData;
  } catch (err) {
    console.warn('Fallback to local beat data:', err);
    if (beatIndex === 0 && currentECGAnalysis.selected_beat_gradcam) {
      renderBeatGradCAMInspector({
        beat_index: 0,
        summary: currentECGAnalysis.beats[0],
        raw_signal: currentECGAnalysis.selected_beat_gradcam.raw_signal,
        gradcam_activations: currentECGAnalysis.selected_beat_gradcam.gradcam_activations,
        lead_names: currentECGAnalysis.metadata.lead_names,
      });
    }
  }
}

function renderBeatGradCAMInspector(beatData) {
  const sum = beatData.summary;
  const isPVC = sum.predicted_class === 1;

  // Update header text
  const badge = $('#inspector-badge');
  if (badge) {
    badge.textContent = `Beat #${beatData.beat_index} (${sum.class_label})`;
    badge.style.background = isPVC ? '#FEE2E2' : '#DCFCE7';
    badge.style.color = isPVC ? '#991B1B' : '#166534';
    badge.style.borderColor = isPVC ? '#FCA5A5' : '#86EFAC';
  }

  const title = $('#inspector-title');
  if (title) {
    title.textContent = `Heartbeat #${beatData.beat_index} at ${sum.time_sec}s (Sample ${sum.r_peak_sample})`;
  }

  const sub = $('#inspector-subtitle');
  if (sub) {
    sub.innerHTML = `Predicted: <strong style="color:${isPVC ? '#DC2626' : '#16A34A'}">${sum.class_label}</strong> &bull; Confidence: <strong>${sum.confidence_percent}%</strong> &bull; PVC Probability: <strong>${sum.pvc_percent}%</strong>`;
  }

  // 1. Draw 256-sample raw heartbeat canvas
  const canvasRaw = $('#beat-waveform-canvas');
  if (canvasRaw && beatData.raw_signal) {
    const ctx = canvasRaw.getContext('2d');
    canvasRaw.width = canvasRaw.parentElement.offsetWidth || 400;
    canvasRaw.height = 150;
    drawBeatRawWaveform(ctx, canvasRaw.width, canvasRaw.height, beatData.raw_signal);
  }

  // 2. Draw 1D Grad-CAM heatmap canvas
  const canvasGrad = $('#beat-gradcam-canvas');
  if (canvasGrad && beatData.raw_signal && beatData.gradcam_activations) {
    const ctx = canvasGrad.getContext('2d');
    canvasGrad.width = canvasGrad.parentElement.offsetWidth || 400;
    canvasGrad.height = 150;
    drawBeatGradCAMHeatmap(ctx, canvasGrad.width, canvasGrad.height, beatData.raw_signal, beatData.gradcam_activations);
  }

  // Explanation note
  const expNote = $('#gradcam-beat-explanation');
  if (expNote) {
    if (isPVC) {
      expNote.innerHTML = `<strong>⚠️ 1D Grad-CAM Interpretation (PVC Beat):</strong> The Grad-CAM gradient maps show strong attention concentrated around the widened, ectopic QRS complex (samples 70 – 120). The 1D-CNN identified high morphological divergence from normal sinus conduction, classifying this heartbeat as <strong>Premature Ventricular Contraction</strong> with ${sum.confidence_percent}% confidence.`;
    } else {
      expNote.innerHTML = `<strong>✅ 1D Grad-CAM Interpretation (Normal Beat):</strong> High gradient attention focuses precisely on the physiological R-wave peak (sample 90) and narrow QRS onset/offset. The trained 1D-CNN verified standard ventricular depolarization, classifying this heartbeat as <strong>Normal</strong> with ${sum.confidence_percent}% confidence.`;
    }
  }
}

function drawBeatRawWaveform(ctx, w, h, signal256) {
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#0F1E3C';
  ctx.fillRect(0, 0, w, h);

  // Grid
  ctx.strokeStyle = 'rgba(20, 184, 166, 0.1)';
  ctx.lineWidth = 0.5;
  for (let x = 0; x < w; x += 25) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }
  for (let y = 0; y < h; y += 25) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }

  const n = signal256.length; // 256
  const midY = h / 2;
  const scaleY = h * 0.35;

  // Draw Lead 2 first (light blue)
  ctx.beginPath();
  ctx.strokeStyle = '#60A5FA';
  ctx.lineWidth = 1.5;
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * w;
    const y = midY - (signal256[i][1] * scaleY);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Draw Lead 1 (vibrant cyan)
  ctx.beginPath();
  ctx.strokeStyle = '#14B8A6';
  ctx.lineWidth = 2;
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * w;
    const y = midY - (signal256[i][0] * scaleY);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // R-Peak marker at sample 90
  const rX = (90 / (n - 1)) * w;
  const rY = midY - (signal256[90][0] * scaleY);
  ctx.beginPath();
  ctx.arc(rX, rY, 4.5, 0, 2 * Math.PI);
  ctx.fillStyle = '#EF4444';
  ctx.fill();
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Vertical dashed guide line at R peak
  ctx.setLineDash([3, 3]);
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
  ctx.beginPath();
  ctx.moveTo(rX, 0); ctx.lineTo(rX, h); ctx.stroke();
  ctx.setLineDash([]);
}

function drawBeatGradCAMHeatmap(ctx, w, h, signal256, activations256) {
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#0F1E3C';
  ctx.fillRect(0, 0, w, h);

  const n = signal256.length; // 256
  const midY = h / 2;
  const scaleY = h * 0.35;

  // Draw vertical gradient bands behind waveform according to Grad-CAM activation intensity
  const bandW = w / n;
  for (let i = 0; i < n; i++) {
    const act = activations256[i] !== undefined ? activations256[i] : 0.0;
    // Map act [0, 1] to color: low (dark blue/teal) -> mid (amber) -> high (red)
    let r, g, b, alpha;
    if (act < 0.35) {
      r = 15; g = 30 + Math.round(act * 100); b = 60 + Math.round(act * 200); alpha = act * 0.6;
    } else if (act < 0.7) {
      const norm = (act - 0.35) / 0.35;
      r = Math.round(20 + norm * 220); g = Math.round(180 - norm * 40); b = 20; alpha = 0.3 + norm * 0.4;
    } else {
      const norm = (act - 0.7) / 0.3;
      r = Math.round(240 + norm * 15); g = Math.round(140 - norm * 100); b = 20; alpha = 0.7 + norm * 0.3;
    }

    ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${Math.max(0.05, alpha)})`;
    ctx.fillRect(i * bandW, 0, Math.ceil(bandW) + 1, h);
  }

  // Draw the signal waveform on top with color highlighting
  ctx.beginPath();
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 1.75;
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * w;
    const y = midY - (signal256[i][0] * scaleY);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Draw activation heatmap intensity bar at the bottom
  const barH = 8;
  const barY = h - barH - 4;
  for (let i = 0; i < n; i++) {
    const act = activations256[i] !== undefined ? activations256[i] : 0.0;
    ctx.fillStyle = getGradCAMColor(act);
    ctx.fillRect(i * bandW, barY, Math.ceil(bandW) + 1, barH);
  }
}

function getGradCAMColor(val) {
  // val between 0.0 and 1.0
  if (val < 0.25) return '#1E293B';
  if (val < 0.5) return '#0D9488';
  if (val < 0.75) return '#F59E0B';
  return '#DC2626';
}

function drawECGPlaceholder() {
  const canvas = $('#ecg-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.width = canvas.parentElement.offsetWidth || 800;
  canvas.height = 180;
  drawECGWavePlaceholder(ctx, canvas.width, canvas.height);
}

function drawECGWavePlaceholder(ctx, w, h) {
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#0F1E3C';
  ctx.fillRect(0, 0, w, h);

  // Grid
  ctx.strokeStyle = 'rgba(20,184,166,0.1)';
  ctx.lineWidth = 0.5;
  for (let x = 0; x < w; x += 20) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }
  for (let y = 0; y < h; y += 20) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }

  ctx.fillStyle = 'rgba(255,255,255,0.45)';
  ctx.font = '13px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Upload MIT-BIH .dat + .hea files or click "Analyze Built-in MIT-BIH Record 100" to decode real ECG signals', w / 2, h / 2);
}


/* =====================================================
   XAI RESULTS PAGE
   ===================================================== */
function initXAI() {
  renderXAIBanner();
  renderSHAP();
  renderLIME();
  renderGradCAM();
  setupXAITabs();

  // If a clinical prediction was run but XAI is not yet cached, fetch it on-demand
  if (window._lastClinicalResult && window._lastPayload && !window._lastXAIResult && !window._isFetchingXAI) {
    window._isFetchingXAI = true;
    const shapChart = $('#shap-chart');
    if (shapChart) {
      shapChart.innerHTML = '<div style="text-align:center;padding:2.5rem 1rem;color:var(--text-muted);"><div class="spinner" style="margin:0 auto 1rem;width:32px;height:32px;border:3px solid var(--border);border-top-color:var(--teal);border-radius:50%;animation:spin 0.8s linear infinite;"></div>Calculating real SHAP feature attributions with KernelExplainer...</div>';
    }
    const limeGrid = $('#lime-grid');
    if (limeGrid) {
      limeGrid.innerHTML = '<div style="text-align:center;padding:2.5rem 1rem;color:var(--text-muted);grid-column:1/-1;"><div class="spinner" style="margin:0 auto 1rem;width:32px;height:32px;border:3px solid var(--border);border-top-color:var(--teal);border-radius:50%;animation:spin 0.8s linear infinite;"></div>Computing local surrogate explanation rules with LIME...</div>';
    }

    fetch(`${API_BASE_URL}/explain/clinical`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(window._lastPayload),
    })
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        window._isFetchingXAI = false;
        if (data) {
          window._lastXAIResult = data;
          renderSHAP();
          renderLIME();
        }
      })
      .catch(err => {
        window._isFetchingXAI = false;
        console.warn('On-demand XAI calculation note:', err);
      });
  }
}

function renderXAIBanner() {
  const result   = window._lastClinicalResult;
  const bannerEl = $('#xai-result-banner');
  if (!bannerEl) return;

  if (result) {
    bannerEl.className = `result-banner ${result.risk === 'High' ? 'high-risk' : 'low-risk'}`;
    bannerEl.style.background = '';
    bannerEl.style.border = '';
    $('#xai-result-icon').textContent   = result.risk === 'High' ? '⚠️' : '✅';
    $('#xai-result-title').textContent  = `${result.risk} Risk (${result.probability_percent}%) — Prediction Explanation`;
    if ($('#xai-result-desc')) $('#xai-result-desc').remove();
    const confEl = $('#xai-confidence');
    if (confEl) {
      confEl.textContent    = `${result.probability_percent}%`;
      confEl.style.fontSize = '';
      confEl.style.color    = '';
    }
  } else {
    bannerEl.className = 'result-banner';
    bannerEl.style.background = 'var(--bg-light)';
    bannerEl.style.border     = '1px solid var(--border)';
    $('#xai-result-icon').textContent   = '🔬';
    $('#xai-result-title').textContent  = 'Awaiting Prediction — Run Clinical Prediction First';
    if ($('#xai-result-desc')) $('#xai-result-desc').remove();
    const confEl = $('#xai-confidence');
    if (confEl) {
      confEl.textContent    = 'Pending';
      confEl.style.fontSize = '1rem';
      confEl.style.color    = 'var(--text-muted)';
    }
  }
}

function renderSHAP() {
  const chart = $('#shap-chart');
  if (!chart) return;
  const tag = $('#shap-tag');

  const xaiData = window._lastXAIResult;

  if (xaiData && Array.isArray(xaiData.shap) && xaiData.shap.length > 0) {
    if (tag) {
      tag.textContent = '📊 SHAP Feature Importance';
      tag.style.background = '#E0F2FE';
      tag.style.color = '#0369A1';
      tag.style.borderColor = '#BAE6FD';
    }

    const shapItems = xaiData.shap;
    const maxVal = Math.max(...shapItems.map(d => Math.abs(d.value))) || 1.0;

    chart.innerHTML = shapItems.map(d => {
      const pct = Math.max(10, Math.min(100, Math.round((Math.abs(d.value) / maxVal) * 100)));
      const cls = d.positive ? 'shap-pos' : 'shap-neg';
      const dirText = d.positive ? '▲ Increases Risk' : '▼ Decreases Risk';
      const displayVal = (d.raw_value !== undefined ? d.raw_value : d.value).toFixed(3);

      return `
        <div class="shap-bar-row">
          <span class="shap-label" title="${d.label}">${d.label}</span>
          <div class="shap-track">
            <div class="shap-fill ${cls}" style="width:${pct}%">
              ${pct > 25 ? dirText : ''}
            </div>
          </div>
          <span class="shap-val">${displayVal}</span>
        </div>`;
    }).join('');
  } else {
    if (tag) {
      tag.textContent = 'Awaiting Clinical Run';
      tag.style.background = '';
      tag.style.color = '';
      tag.style.borderColor = '';
    }

    chart.innerHTML = `
      <div style="text-align:center;padding:2.5rem 1rem;color:var(--text-muted)">
        <div style="font-size:2rem;margin-bottom:0.5rem">📊</div>
        <h4 style="margin:0 0 0.35rem;color:var(--navy);font-size:1rem">No Clinical Run Yet</h4>
        <p style="margin:0;font-size:0.82rem">Please navigate to <strong>Clinical Prediction</strong>, enter patient features, and click <strong>Run Prediction</strong>.<br/>Real SHAP feature attributions calculated by the prediction model will appear here.</p>
      </div>`;
  }
}

function renderLIME() {
  const grid = $('#lime-grid');
  if (!grid) return;
  const tag = $('#lime-tag');

  const xaiData = window._lastXAIResult;

  if (xaiData && Array.isArray(xaiData.lime) && xaiData.lime.length > 0) {
    if (tag) {
      tag.textContent = '🍋 LIME Explanation Rules';
      tag.style.background = '#E0F2FE';
      tag.style.color = '#0369A1';
      tag.style.borderColor = '#BAE6FD';
    }

    const limeItems = xaiData.lime;

    grid.innerHTML = limeItems.map(d => {
      const cls = d.positive ? 'lime-pos' : 'lime-neg';
      const impactLabel = d.positive ? '⬆ Increases Risk' : '⬇ Decreases Risk';

      return `
        <div class="lime-feat">
          <div class="lime-feat-name">${d.name}</div>
          <div class="lime-feat-val" style="font-size:0.75rem;color:var(--text-secondary);margin:0.2rem 0;line-height:1.3" title="${d.rule || d.name}">
            <code>${d.rule || d.name}</code>
          </div>
          <div class="lime-impact-bar">
            <div class="lime-impact-fill ${cls}" style="width:${d.weight}%"></div>
          </div>
          <div class="lime-weight">Impact: ${d.weight}% · ${impactLabel}</div>
        </div>`;
    }).join('');
  } else {
    if (tag) {
      tag.textContent = 'Awaiting Clinical Run';
      tag.style.background = '';
      tag.style.color = '';
      tag.style.borderColor = '';
    }

    grid.innerHTML = `
      <div style="text-align:center;padding:2.5rem 1rem;color:var(--text-muted);grid-column:1/-1">
        <div style="font-size:2rem;margin-bottom:0.5rem">🍋</div>
        <h4 style="margin:0 0 0.35rem;color:var(--navy);font-size:1rem">No Clinical Run Yet</h4>
        <p style="margin:0;font-size:0.82rem">Please navigate to <strong>Clinical Prediction</strong>, enter patient features, and click <strong>Run Prediction</strong>.<br/>Real LIME local surrogate rules calculated by the prediction model will appear here.</p>
      </div>`;
  }
}

function renderGradCAM() {
  const c1 = $('#gradcam-original');
  const c2 = $('#gradcam-heatmap');
  const tag = $('#gradcam-tag');
  if (!c1 || !c2) return;

  const beatData = window._lastECGBeat || (window._lastECGAnalysis ? window._lastECGAnalysis.selected_beat_gradcam : null);

  if (beatData && beatData.raw_signal && beatData.gradcam_activations) {
    if (tag) {
      tag.textContent = `🤖 Live 1D Grad-CAM (conv1d_2: Beat #${beatData.beat_index})`;
      tag.style.background = '#E0F2FE';
      tag.style.color = '#0369A1';
      tag.style.borderColor = '#BAE6FD';
    }

    c1.width = c1.parentElement.offsetWidth || 300;
    c1.height = 120;
    drawBeatRawWaveform(c1.getContext('2d'), c1.width, c1.height, beatData.raw_signal);

    c2.width = c2.parentElement.offsetWidth || 300;
    c2.height = 120;
    drawBeatGradCAMHeatmap(c2.getContext('2d'), c2.width, c2.height, beatData.raw_signal, beatData.gradcam_activations);
  } else {
    if (tag) {
      tag.textContent = 'Awaiting ECG Analysis';
      tag.style.background = '';
      tag.style.color = '';
      tag.style.borderColor = '';
    }

    c1.width = c1.parentElement.offsetWidth || 300;
    c1.height = 120;
    const ctx1 = c1.getContext('2d');
    ctx1.fillStyle = '#0F1E3C';
    ctx1.fillRect(0, 0, c1.width, c1.height);
    ctx1.fillStyle = 'rgba(255,255,255,0.4)';
    ctx1.font = '12px Inter, sans-serif';
    ctx1.textAlign = 'center';
    ctx1.fillText('Navigate to ECG Analysis to decode a recording', c1.width / 2, c1.height / 2);

    c2.width = c2.parentElement.offsetWidth || 300;
    c2.height = 120;
    const ctx2 = c2.getContext('2d');
    ctx2.fillStyle = '#0F1E3C';
    ctx2.fillRect(0, 0, c2.width, c2.height);
    ctx2.fillStyle = 'rgba(255,255,255,0.4)';
    ctx2.font = '12px Inter, sans-serif';
    ctx2.textAlign = 'center';
    ctx2.fillText('Real 1D Grad-CAM will appear here', c2.width / 2, c2.height / 2);
  }
}

function setupXAITabs() {
  $$('.xai-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      $$('.xai-tab').forEach(t => t.classList.remove('active'));
      $$('.xai-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      $(`#xai-panel-${tab.dataset.tab}`).classList.add('active');
    });
  });
}

/* =====================================================
   HISTORY PAGE
   ===================================================== */
function renderHistory() {
  const tbody  = $('#history-tbody');
  const empty  = $('#history-empty');
  if (!tbody) return;

  const history  = getHistory();
  const query    = ($('#history-search')?.value || '').toLowerCase();
  const filter   = $('#history-filter')?.value || 'all';

  let items = history;
  if (filter !== 'all') items = items.filter(h => h.type === filter);
  if (query)            items = items.filter(h => h.label.toLowerCase().includes(query) || h.type.toLowerCase().includes(query));

  if (items.length === 0) {
    tbody.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  tbody.innerHTML = items.map((h, i) => {
    const badgeCls = h.risk === 'High' ? 'badge-high' : h.risk === 'Low' ? 'badge-low' : 'badge-normal';
    const typeCls  = h.type === 'ecg' ? 'type-ecg' : 'type-clinical';
    return `
      <tr>
        <td style="color:var(--text-muted);font-size:0.75rem">#${String(i + 1).padStart(3, '0')}</td>
        <td>${h.date}</td>
        <td><span class="type-pill ${typeCls}">${h.type === 'ecg' ? '📈 ECG' : '🏥 Clinical'}</span></td>
        <td>${h.label}</td>
        <td>${h.prob !== undefined ? `${h.prob}%` : '—'}</td>
        <td><span class="activity-badge ${badgeCls}">${h.risk || 'Done'}</span></td>
        <td><button class="btn btn-sm btn-outline" onclick="deleteHistory(${h.id})">🗑</button></td>
      </tr>`;
  }).join('');
}

function deleteHistory(id) {
  const history = getHistory().filter(h => h.id !== id);
  localStorage.setItem(LS_KEY, JSON.stringify(history));
  renderHistory();
  updateDashboardStats();
  showToast('Record deleted.', 'info');
}

function clearAllHistory() {
  if (!confirm('Clear all history records? This cannot be undone.')) return;
  localStorage.removeItem(LS_KEY);
  renderHistory();
  updateDashboardStats();
  showToast('History cleared.', 'info');
}

/* =====================================================
   SIDEBAR & MOBILE
   ===================================================== */
function setupSidebar() {
  /* Nav items */
  $$('.nav-item').forEach(item => {
    item.addEventListener('click', () => navigate(item.dataset.page));
  });

  /* Mobile toggle */
  $('#menu-toggle').addEventListener('click', () => {
    $('#sidebar').classList.toggle('open');
    $('#sidebar-overlay').classList.toggle('show');
  });

  /* Overlay click closes sidebar */
  $('#sidebar-overlay').addEventListener('click', () => {
    $('#sidebar').classList.remove('open');
    $('#sidebar-overlay').classList.remove('show');
  });
}

/* =====================================================
   BOOT / INIT
   ===================================================== */
function init() {
  /* Login */
  $('#login-form').addEventListener('submit', handleLogin);
  $('#fill-demo-btn')?.addEventListener('click', fillDemo);
  $('#btn-logout').addEventListener('click', handleLogout);
  setupPasswordToggle();

  /* Sidebar */
  setupSidebar();

  /* Dashboard module cards and open buttons */
  $('#dash-open-clinical')?.addEventListener('click', (e) => { e.stopPropagation(); navigate('clinical'); });
  $('#dash-open-ecg')?.addEventListener('click', (e) => { e.stopPropagation(); navigate('ecg'); });
  $('#card-module-clinical')?.addEventListener('click', () => navigate('clinical'));
  $('#card-module-ecg')?.addEventListener('click', () => navigate('ecg'));
  $('#dash-card-clinical')?.addEventListener('click', () => navigate('clinical'));
  $('#dash-card-ecg')?.addEventListener('click', () => navigate('ecg'));
  $('#dash-view-history')?.addEventListener('click', () => navigate('history'));

  /* Clinical form */
  setupClinicalForm();

  /* XAI nav from result */
  $('#view-xai-btn')?.addEventListener('click', () => navigate('xai'));

  /* ECG */
  setupECGPage();

  /* History controls */
  $('#history-search')?.addEventListener('input', renderHistory);
  $('#history-filter')?.addEventListener('change', renderHistory);
  $('#clear-history-btn')?.addEventListener('click', clearAllHistory);

  /* Backend health monitor */
  checkBackendStatus();
  setInterval(checkBackendStatus, 20000);
  $('#api-status-badge')?.addEventListener('click', () => {
    showToast('Checking backend connection…', 'info', 2000);
    checkBackendStatus();
  });

  /* Init dashboard stats */
  updateDashboardStats();

  /* Start on login page */
  navigate('login');
}

document.addEventListener('DOMContentLoaded', init);
